from setuptools import setup, find_packages

setup(
    name="torch-dtrn-accel",
    version="0.1.0",
    description="PyTorch DTRN/PE-GADTRN acceleration primitives",
    packages=find_packages(),
    install_requires=["torch"],
    python_requires=">=3.9",
)
