"""
Example replacements for current DTRN notebooks/apps.

CIFAR notebook:
    replace SparseGivensRotation(dim, rounds) with GivensChain(dim, rounds)

LLM/FastMicroLlama notebook:
    replace SparseGivensChain(dim, layers) with GivensChain(dim, rounds=layers)

Mac app:
    replace local SparseGivensChain class with torch_dtrn.GivensChain
"""

from torch_dtrn import GivensChain, PEGADTRNFFN, LowRankTensorGate

# CIFAR:
# self.rot = SparseGivensRotation(dim, givens_rounds)
# becomes:
# self.rot = GivensChain(dim, rounds=givens_rounds)

# FastMicroLlama:
# self.rot = SparseGivensChain(dim, layers=givens_layers)
# becomes:
# self.rot = GivensChain(dim, rounds=givens_layers)

# PE-GADTRN FFN:
# self.feed_forward = PEGADTRNFFN(dim, rank=160, givens_rounds=5)
