"""
torch_dtrn.givens

Drop-in PyTorch primitives for DTRN / PE-GADTRN rotations.

Why this exists
---------------
The current DTRN notebooks implement Givens rotations as:
    index_select -> cos/sin -> clone -> indexed assignment
That is mathematically correct and orthogonal by construction, but it lets
generic autograd build a scatter-heavy backward graph.

This module uses a custom autograd function for each sparse Givens round:
  * forward applies only paired 2x2 rotations;
  * backward uses the orthogonal inverse R^T for grad_x;
  * grad_theta uses the closed-form derivative of a Givens rotation.

It is still pure PyTorch, so it runs on CPU, CUDA, and Apple MPS, and can be
wrapped with torch.compile where supported. For maximum speed on CUDA, the
next step would be a native Triton/CUDA kernel using the same formulas.
"""

from __future__ import annotations

import math
from typing import Optional

import torch
import torch.nn as nn


class _GivensRoundFn(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x: torch.Tensor, theta: torch.Tensor, offset: int):
        # Rotates pairs:
        #   y_i = cos(theta) x_i - sin(theta) x_j
        #   y_j = sin(theta) x_i + cos(theta) x_j
        #
        # Offset 0 pairs (0,1), (2,3), ...
        # Offset 1 pairs (1,2), (3,4), ...
        D = x.shape[-1]
        offset = int(offset)
        n_pairs = (D - offset) // 2
        ctx.offset = offset
        ctx.n_pairs = n_pairs
        ctx.theta_numel = theta.numel()

        if n_pairs <= 0:
            ctx.save_for_backward(theta.new_empty(0), theta.new_empty(0))
            return x

        theta_used = theta[:n_pairs]
        c = torch.cos(theta_used).to(device=x.device, dtype=x.dtype)
        s = torch.sin(theta_used).to(device=x.device, dtype=x.dtype)

        seg = x[..., offset:offset + 2 * n_pairs]
        pair = seg.reshape(*seg.shape[:-1], n_pairs, 2)
        x0 = pair[..., 0]
        x1 = pair[..., 1]

        y0 = c * x0 - s * x1
        y1 = s * x0 + c * x1
        y_pair = torch.stack((y0, y1), dim=-1)

        y = x.clone()
        y[..., offset:offset + 2 * n_pairs] = y_pair.reshape(*seg.shape)

        # Save the forward output on each rotated pair and theta.
        # Grad theta can be written compactly using y:
        #   dE/dtheta = sum(-g_i*y_j + g_j*y_i)
        ctx.save_for_backward(y_pair, theta_used)
        return y

    @staticmethod
    def backward(ctx, grad_out: torch.Tensor):
        y_pair, theta_used = ctx.saved_tensors
        offset = ctx.offset
        n_pairs = ctx.n_pairs
        theta_numel = ctx.theta_numel

        if n_pairs <= 0:
            return grad_out, None, None

        c = torch.cos(theta_used).to(device=grad_out.device, dtype=grad_out.dtype)
        s = torch.sin(theta_used).to(device=grad_out.device, dtype=grad_out.dtype)

        gseg = grad_out[..., offset:offset + 2 * n_pairs]
        gpair = gseg.reshape(*gseg.shape[:-1], n_pairs, 2)
        g0 = gpair[..., 0]
        g1 = gpair[..., 1]

        # Since R is orthogonal, dL/dx = R^T dL/dy.
        gx0 = c * g0 + s * g1
        gx1 = -s * g0 + c * g1

        grad_x = grad_out.clone()
        gx_pair = torch.stack((gx0, gx1), dim=-1)
        grad_x[..., offset:offset + 2 * n_pairs] = gx_pair.reshape(*gseg.shape)

        y0 = y_pair[..., 0]
        y1 = y_pair[..., 1]
        gtheta = -g0 * y1 + g1 * y0
        reduce_dims = tuple(range(gtheta.ndim - 1))
        if reduce_dims:
            gtheta = gtheta.sum(dim=reduce_dims)

        grad_theta = torch.zeros(theta_numel, dtype=theta_used.dtype, device=theta_used.device)
        grad_theta[:n_pairs] = gtheta
        return grad_x, grad_theta, None


class GivensRound(nn.Module):
    """
    One disjoint sparse Givens round.

    Parameters
    ----------
    dim:
        Last dimension of the input.
    offset:
        0 for pairs (0,1),(2,3),...
        1 for pairs (1,2),(3,4),...
    init_scale:
        Stddev for small-angle initialization.
    """

    def __init__(self, dim: int, offset: int = 0, init_scale: float = 0.015):
        super().__init__()
        self.dim = int(dim)
        self.offset = int(offset)
        self.n_pairs = max(0, (self.dim - self.offset) // 2)
        self.theta = nn.Parameter(torch.empty(self.n_pairs))
        nn.init.normal_(self.theta, mean=0.0, std=init_scale)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return _GivensRoundFn.apply(x, self.theta, self.offset)


class GivensChain(nn.Module):
    """
    Sparse Givens-chain orthogonal mixer.

    This replaces the clone/index/scatter Givens implementations in the
    current CIFAR, LLM, FastMicroLlama, and Mac-app code.

    Advantages
    ----------
    * Orthogonal by construction.
    * O(dim * rounds) trainable parameters, not O(dim^2).
    * Backward explicitly applies R^T for grad_x.
    * No index tensors are rebuilt each forward.
    * Pure PyTorch; supports CUDA, CPU, and Apple MPS.
    """

    def __init__(self, dim: int, rounds: int = 4, init_scale: float = 0.015):
        super().__init__()
        self.dim = int(dim)
        self.rounds = int(rounds)
        self.layers = nn.ModuleList([
            GivensRound(self.dim, offset=(r % 2), init_scale=init_scale)
            for r in range(self.rounds)
        ])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for layer in self.layers:
            x = layer(x)
        return x

    @property
    def num_rotation_params(self) -> int:
        return sum(layer.theta.numel() for layer in self.layers)


@torch.no_grad()
def orthogonality_error(module: GivensChain, dim: Optional[int] = None, device: Optional[torch.device] = None) -> float:
    """
    Materialize the rotation on an identity matrix and return ||R^T R - I||_F.

    Use only for debugging/small dimensions; it intentionally builds a dense
    diagnostic matrix.
    """
    dim = int(dim or module.dim)
    device = device or next(module.parameters()).device
    eye = torch.eye(dim, device=device)
    R = module(eye)
    err = torch.linalg.norm(R.T @ R - eye).item()
    return float(err)
