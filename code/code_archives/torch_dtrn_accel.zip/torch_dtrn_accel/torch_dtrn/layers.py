"""
torch_dtrn.layers

PE-GADTRN / DTRN building blocks implemented as normal PyTorch modules.
These modules are intended as drop-in replacements for the ad hoc copies
currently living inside notebooks and desktop-app scripts.
"""

from __future__ import annotations

import math
import torch
import torch.nn as nn
import torch.nn.functional as F

from .givens import GivensChain


class LoRALinear(nn.Module):
    def __init__(self, in_features: int, out_features: int, bias: bool = False,
                 r: int = 0, alpha: float = 16.0, dropout: float = 0.0):
        super().__init__()
        self.base = nn.Linear(in_features, out_features, bias=bias)
        self.r = int(r)
        self.alpha = float(alpha)
        self.scaling = self.alpha / self.r if self.r > 0 else 1.0
        self.drop = nn.Dropout(dropout)
        if self.r > 0:
            self.lora_A = nn.Parameter(torch.empty(self.r, in_features))
            self.lora_B = nn.Parameter(torch.empty(out_features, self.r))
            nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))
            nn.init.zeros_(self.lora_B)
        else:
            self.register_parameter("lora_A", None)
            self.register_parameter("lora_B", None)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y = self.base(x)
        if self.r > 0:
            z = F.linear(self.drop(x), self.lora_A)
            y = y + F.linear(z, self.lora_B) * self.scaling
        return y


class DenseSwiGLUFFN(nn.Module):
    def __init__(self, dim: int, ffn_dim: int, dropout: float = 0.0,
                 lora_r: int = 0, lora_alpha: float = 16.0):
        super().__init__()
        self.w1 = LoRALinear(dim, ffn_dim, bias=False, r=lora_r, alpha=lora_alpha)
        self.w3 = LoRALinear(dim, ffn_dim, bias=False, r=lora_r, alpha=lora_alpha)
        self.w2 = LoRALinear(ffn_dim, dim, bias=False, r=lora_r, alpha=lora_alpha)
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.drop(self.w2(F.silu(self.w1(x)) * self.w3(x)))


class LowRankTensorGate(nn.Module):
    """
    PE-GADTRN low-rank gated tensor mixer for vision/token blocks.

    This is the same conceptual layer used in the CIFAR notebook, but it
    uses the optimized GivensChain module.
    """
    def __init__(self, dim: int, rank: int, dropout: float = 0.0,
                 givens_rounds: int = 2, init_scale: float = 0.015):
        super().__init__()
        self.rot = GivensChain(dim, rounds=givens_rounds, init_scale=init_scale)
        self.a = nn.Linear(dim, rank, bias=False)
        self.b = nn.Linear(dim, rank, bias=False)
        self.out = nn.Linear(rank, dim, bias=False)
        self.scale = nn.Parameter(torch.ones(rank))
        self.drop = nn.Dropout(dropout)
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.a.base.weight if hasattr(self.a, "base") else self.a.weight)
        nn.init.xavier_uniform_(self.b.base.weight if hasattr(self.b, "base") else self.b.weight)
        nn.init.zeros_(self.out.weight)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = self.rot(x)
        h = F.gelu(self.a(z)) * self.b(z)
        return self.drop(self.out(h * self.scale))


class PEGADTRNFFN(nn.Module):
    """
    FFN replacement using PE-GADTRN.

    Designed for Llama/FastMicroLlama FFN-first compression:
      * keep attention/RoPE/GQA dense;
      * replace SwiGLU FFN with a sparse orthogonal low-rank mixer;
      * keep a small norm gate so the adapter can change magnitudes.
    """
    def __init__(self, dim: int, rank: int = 160, givens_rounds: int = 5,
                 dropout: float = 0.0, alpha: float = 1.0):
        super().__init__()
        self.rank = int(rank)
        self.alpha = float(alpha)
        self.rot = GivensChain(dim, rounds=givens_rounds)
        self.down = nn.Linear(dim, self.rank, bias=False)
        self.gate = nn.Linear(dim, self.rank, bias=False)
        self.mix = nn.Parameter(torch.randn(self.rank, self.rank) / math.sqrt(self.rank))
        self.mix_diag = nn.Parameter(torch.ones(self.rank))
        self.up = nn.Linear(self.rank, dim, bias=False)
        self.norm_gate = nn.Parameter(torch.zeros(dim))
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        xr = self.rot(x)
        z = self.down(xr)
        h = z * torch.sigmoid(self.gate(x))
        h = F.linear(h, self.mix) * self.mix_diag
        h = F.silu(h)
        y = self.up(h)
        y = y * (1.0 + 0.1 * torch.tanh(self.norm_gate))
        return self.drop(y) * self.alpha


class PEAdapterSwiGLUFFN(nn.Module):
    """
    Dense SwiGLU plus trainable PE-GADTRN residual adapter.

    Use this for LoRA-like trainable-parameter compression comparisons.
    """
    def __init__(self, dim: int, ffn_dim: int, rank: int = 96,
                 givens_rounds: int = 4, dropout: float = 0.0,
                 alpha: float = 1.0):
        super().__init__()
        self.dense = DenseSwiGLUFFN(dim, ffn_dim, dropout=dropout, lora_r=0)
        self.adapter = PEGADTRNFFN(dim, rank=rank, givens_rounds=givens_rounds,
                                   dropout=dropout, alpha=alpha)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.dense(x) + self.adapter(x)


# Backwards-compatible name used in some generated code.
PEAdapterSwiGLU = PEAdapterSwiGLUFFN
