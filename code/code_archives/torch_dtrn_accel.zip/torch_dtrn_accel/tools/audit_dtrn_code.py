#!/usr/bin/env python3
"""
Static audit helper for DTRN code.

Usage:
    python tools/audit_dtrn_code.py path/to/file.py path/to/notebook.ipynb

It checks for common slow Givens patterns:
  * clone + indexed assignment
  * torch.arange created inside forward
  * pair indices stored as Python lists instead of buffers
  * no custom Givens/autograd primitive
"""

import json
import re
import sys
from pathlib import Path

def read_text(path):
    p = Path(path)
    if p.suffix == ".ipynb":
        nb = json.loads(p.read_text())
        out = []
        for cell in nb.get("cells", []):
            if cell.get("cell_type") == "code":
                src = cell.get("source", "")
                out.append("".join(src) if isinstance(src, list) else src)
        return "\n".join(out)
    return p.read_text(errors="replace")

def audit(path):
    src = read_text(path)
    flags = []
    if "Givens" not in src and "givens" not in src:
        flags.append("no Givens rotation implementation found")
    if ".clone()" in src and ("index_select" in src or "[..., idx_" in src or "[...,i]" in src):
        flags.append("clone/index/scatter pattern likely in rotation forward")
    if re.search(r"def forward\\(.*?torch\\.arange", src, re.S):
        flags.append("torch.arange appears inside forward; precompute or avoid indices")
    if "torch.autograd.Function" not in src and ("SparseGivens" in src or "GivensChain" in src):
        flags.append("uses generic autograd for Givens; no custom orthogonal backward")
    if "register_buffer" not in src and ("pair_i" in src or "idx_i" in src or "i_" in src):
        flags.append("rotation indices may not be registered buffers")
    return flags

def main(argv):
    for arg in argv[1:]:
        flags = audit(arg)
        print(f"\n{arg}")
        if not flags:
            print("  OK: no obvious slow-path flags")
        else:
            for f in flags:
                print("  -", f)

if __name__ == "__main__":
    main(sys.argv)
