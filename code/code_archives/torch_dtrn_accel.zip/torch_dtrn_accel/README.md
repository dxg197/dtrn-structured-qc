# torch_dtrn_accel

A drop-in PyTorch extension package for DTRN / PE-GADTRN experiments.

This is **not a fork of PyTorch**. It is the practical first step: a normal
PyTorch package that centralizes DTRN primitives and replaces slow ad hoc
notebook implementations.

## What it adds

- `GivensChain`: sparse orthogonal rotations with custom backward
- `PEGADTRNFFN`: FFN-first PE-GADTRN replacement
- `PEAdapterSwiGLUFFN`: dense SwiGLU plus PE-GADTRN residual adapter
- `LoRALinear`: LoRA baseline support
- static audit helper for existing notebooks/apps

## Installation

In Colab or a local project folder:

```bash
unzip torch_dtrn_accel.zip
cd torch_dtrn_accel
pip install -e .
```

Because this package is pure PyTorch, it works on CUDA, CPU, and Apple MPS
without compiling custom C++/CUDA.

## Quick use

```python
from torch_dtrn import GivensChain, PEGADTRNFFN

rot = GivensChain(dim=768, rounds=5)
ffn = PEGADTRNFFN(dim=768, rank=160, givens_rounds=5)
```

## Replace current notebook code

CIFAR:

```python
self.rot = SparseGivensRotation(dim, givens_rounds)
```

becomes:

```python
from torch_dtrn import GivensChain
self.rot = GivensChain(dim, rounds=givens_rounds)
```

FastMicroLlama / LLM:

```python
self.rot = SparseGivensChain(dim, layers=givens_layers)
```

becomes:

```python
from torch_dtrn import GivensChain
self.rot = GivensChain(dim, rounds=givens_layers)
```

## Audit existing code

```bash
python tools/audit_dtrn_code.py PE_GADTRN_CIFAR10_3Seed_Colab.ipynb
```

## Expected speed impact

This package should reduce some DTRN rotation overhead, especially during
training backward passes, but it will not by itself overcome the full gap
versus CNN kernels. CNNs are backed by deeply optimized convolution kernels;
DTRN currently uses many small structured operations.

To close a 5x latency gap, the next layer should be:

1. this package as the common API;
2. `torch.compile` around model blocks;
3. a Triton/CUDA fused Givens + low-rank mixer kernel;
4. a Metal/MPS kernel for Mac inference;
5. shape-stable batching and fewer Python-level loops.
