# DTRN Orthogonality / Latency Audit

Scope inspected from the latest generated artifacts in this conversation:

- `PE_GADTRN_CIFAR10_3Seed_Colab.ipynb`
- `LoRA_PE_GADTRN_LLM_Compression_Frontier_Colab.ipynb`
- `FastMicroLlama_PE_GADTRN_Frontier_Colab.ipynb`
- `fast_micro_llama_mac_app_v4_pe_gadtrn.zip`

## Main finding

The latest DTRN/PE-GADTRN code **does exploit orthogonality in the forward parameterization**:
rotations are represented as sparse Givens rotations using `cos(theta)` and `sin(theta)`, not as
dense learned matrices. This is good: it gives orthogonal rotations by construction with O(d)
parameters per round.

However, the code **does not yet exploit orthogonality in the backward pass or runtime kernel**:
PyTorch's generic autograd sees `index_select`, `clone`, and indexed assignment. It does not know
this operation is an orthogonal rotation whose input gradient is simply `R^T grad`.

## Artifact-by-artifact notes

### CIFAR 3-seed notebook

- Uses `SparseGivensRotation`.
- Pair indices are registered as buffers.
- Forward is orthogonal by construction.
- Slow path: `index_select` + `clone` + indexed assignment.
- Backward: generic autograd, not an explicit inverse-rotation backward.

### LoRA + PE-GADTRN micro LLM notebook

- Uses `SparseGivensChain`.
- Pair indices are registered as buffers.
- Forward is orthogonal by construction.
- Slow path: `index_select` + `clone` + indexed assignment.
- Backward: generic autograd.

### FastMicroLlama PE-GADTRN frontier notebook

- Uses `SparseGivensChain`.
- Forward is orthogonal by construction.
- Slow path: `index_select` + `clone` + indexed assignment.
- Extra issue: pair index tensors are stored in Python lists and moved to device inside `forward`.
  This costs avoidable overhead.
- Backward: generic autograd.

### Mac app v4 PE-GADTRN

- Uses `SparseGivensChain`.
- Forward is orthogonal by construction.
- Slow path: creates `torch.arange(...)` inside every forward call.
- Slow path: `index_select` + `clone` + indexed assignment.
- Backward is less important for the app if it is inference-only, but the forward overhead affects latency.

## Recommended immediate patch

Replace local `SparseGivensRotation` / `SparseGivensChain` classes with:

```python
from torch_dtrn import GivensChain
```

Then replace local constructors:

```python
self.rot = SparseGivensRotation(dim, givens_rounds)
self.rot = SparseGivensChain(dim, layers=givens_layers)
```

with:

```python
self.rot = GivensChain(dim, rounds=givens_rounds)
self.rot = GivensChain(dim, rounds=givens_layers)
```

## Why this should help

The included `GivensChain` uses a custom autograd primitive per Givens round:

- forward still performs the sparse rotations;
- backward computes `grad_x = R^T grad_y`;
- `grad_theta = sum(-grad_i*y_j + grad_j*y_i)`;
- no dense rotation matrix is formed;
- no index tensors are rebuilt inside `forward`.

This will not magically make DTRN as optimized as cuDNN CNN kernels, but it removes one clear
avoidable source of overhead. For a larger win, the same formulas should be moved into a fused
Triton/CUDA kernel and eventually an MPS/Metal kernel for Mac inference.
