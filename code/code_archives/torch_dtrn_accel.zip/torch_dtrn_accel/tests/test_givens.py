import torch
from torch_dtrn import GivensChain, orthogonality_error

def test_forward_backward():
    torch.manual_seed(0)
    x = torch.randn(4, 7, 16, requires_grad=True)
    rot = GivensChain(16, rounds=3)
    y = rot(x)
    loss = y.square().mean()
    loss.backward()
    assert x.grad is not None
    for p in rot.parameters():
        assert p.grad is not None

def test_orthogonal_small():
    rot = GivensChain(16, rounds=4)
    err = orthogonality_error(rot, dim=16)
    assert err < 1e-5, err
