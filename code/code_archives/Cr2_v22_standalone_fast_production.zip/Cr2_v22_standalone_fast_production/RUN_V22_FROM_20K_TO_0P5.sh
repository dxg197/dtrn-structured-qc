#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PACKAGE_ROOT="$( cd "$SCRIPT_DIR/.." && pwd )"
cd "$PACKAGE_ROOT"

CONFIG="${CONFIG:-$PACKAGE_ROOT/v22/configs/v22_from_20k_to_0p5.json}"
DRIVER="${DRIVER:-$PACKAGE_ROOT/v22/v22_controller.py}"
ENGINE="${ENGINE:-$PACKAGE_ROOT/engines/cas12/cr2_v1433_cas12_adaptive.py}"
START_DIR="${START_DIR:-}"
OUTPUT_ROOT="${OUTPUT_ROOT:-$PACKAGE_ROOT/v22_runs/from20k_to0p5_$(date +%Y%m%d_%H%M%S)}"

if [ -z "$START_DIR" ]; then
  echo "START_DIR is required for the 20k restart run."
  echo "Example:"
  echo '  START_DIR="$PWD/v21_3_final_results/step028_restart_r10_to20000" ./scripts/RUN_V22_FROM_20K_TO_0P5.sh'
  exit 1
fi

RUN_FLAG=()
if [ "${RUN:-0}" = "1" ]; then
  RUN_FLAG=(--run)
else
  echo "Dry-run only. To execute: RUN=1 $0"
fi

python3 "$DRIVER" \
  --config "$CONFIG" \
  --engine "$ENGINE" \
  --start-dir "$START_DIR" \
  --output-root "$OUTPUT_ROOT" \
  "${RUN_FLAG[@]}"
