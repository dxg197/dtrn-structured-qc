# Cr2 v22 standalone fast production package

This is a standalone v22 orchestration package for Cr2 CAS(12,12) selected-CI production runs.
It is designed from the lessons learned in the v14.35/v21.3/v21.4 archive review.

Primary goal:

```text
Cr2 CAS(12,12), natural-orbital lineage
Target gap: < 0.5 mHa
Walltime target: <= 24 hours on Mac M1, if a new rank/representation unlock occurs or slope holds
```

Important: this package is a self-contained **v22 controller/orchestrator**. It expects the existing
low-level Cr2 selected-CI engine to be available in the package root, normally:

```text
engines/cas12/cr2_v1433_cas12_adaptive.py
engines/cas12/pyscf_hamiltonian_v144.py
engines/cas12/cr2_v1435_no_results/01_make_no/active_rotation_from_restart.npy
```

The uploaded result archives contain the data/provenance needed to design v22, but not a complete
low-level chemistry engine. This package therefore vendors the full control logic, safety checks,
restart detection, walltime strategy, and run scripts, while calling your local engine.

## Why this package exists

The archive review showed:

- v21.3/v14.35 natural-orbital production is the best proven path.
- The correct Cr2 CAS(12,12) Hamiltonian path prints 29717 Pauli terms.
- Runs that print 29709 Pauli terms are basis-incompatible for the v21.3/v14.35 checkpoint lineage.
- Large rank-10 top-k/hybrid production steps are faster than v21.4b diversity microsteps.
- The path to <0.5 mHa probably requires triggered rank-11/12 unlock probes, not brute-force continuation alone.

## Install

Unzip this package into the root of your Cr2 run package, the folder containing `engines/`, `tools/`, and `scripts/`:

```bash
unzip Cr2_v22_standalone_fast_production.zip
cd Cr2_v22_standalone_fast_production
./INSTALL_IN_PACKAGE_ROOT.sh /path/to/Cr2_v21.4b_dtrn_active_rank_package
```

Or from inside the Cr2 package root:

```bash
unzip /path/to/Cr2_v22_standalone_fast_production.zip
cp -R Cr2_v22_standalone_fast_production/v22 .
cp Cr2_v22_standalone_fast_production/RUN_V22_FROM_20K_TO_0P5.sh scripts/
cp Cr2_v22_standalone_fast_production/RUN_V22_FROM_ZERO_24H.sh scripts/
cp Cr2_v22_standalone_fast_production/RUN_V22_PREFLIGHT.sh scripts/
chmod +x scripts/RUN_V22_*.sh v22/*.py v22/tools/*.sh
```

## Preflight

```bash
./scripts/RUN_V22_PREFLIGHT.sh
```

The preflight must confirm the engine exists and the chosen run command includes `--casscf`.
A real run must print:

```text
29717 Pauli terms
```

If it prints `29709 terms`, stop immediately.

## Continue from the best v21.3 20k checkpoint

```bash
START_DIR="$PWD/v21_3_final_results/step028_restart_r10_to20000" \
./scripts/RUN_V22_FROM_20K_TO_0P5.sh
```

If the dry run looks correct, run:

```bash
START_DIR="$PWD/v21_3_final_results/step028_restart_r10_to20000" RUN=1 \
./scripts/RUN_V22_FROM_20K_TO_0P5.sh
```

## From-zero 24h attempt

This is the aggressive full production run. It may get to <0.5 mHa only if the slope holds or a rank-11/12 unlock occurs.

```bash
RUN=1 ./scripts/RUN_V22_FROM_ZERO_24H.sh
```

## Safety rules

v22 refuses to chain if any of these occur:

- E_var becomes non-monotone.
- gap worsens.
- N is not approximately 12.
- Sz is not approximately 0.
- log stream shows 29709 terms or another wrong Hamiltonian signature.
- the first real solve jumps to a high gap.

## Output

Each run writes:

```text
v22_runs/<run_id>/
  v22_progress.csv
  v22_run_config.json
  step000_.../
  step001_.../
```

Use:

```bash
python3 v22/v22_summarize.py v22_runs/<run_id>
```
