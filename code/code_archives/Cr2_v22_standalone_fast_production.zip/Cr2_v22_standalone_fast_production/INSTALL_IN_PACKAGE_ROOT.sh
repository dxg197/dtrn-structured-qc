#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 1 ]; then
  echo "Usage: $0 /path/to/Cr2_package_root"
  exit 1
fi

TARGET="$1"
if [ ! -d "$TARGET" ]; then
  echo "Target directory not found: $TARGET"
  exit 1
fi

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

mkdir -p "$TARGET/scripts"
cp -R "$SCRIPT_DIR/v22" "$TARGET/"
cp "$SCRIPT_DIR/RUN_V22_FROM_20K_TO_0P5.sh" "$TARGET/scripts/"
cp "$SCRIPT_DIR/RUN_V22_FROM_ZERO_24H.sh" "$TARGET/scripts/"
cp "$SCRIPT_DIR/RUN_V22_PREFLIGHT.sh" "$TARGET/scripts/"
chmod +x "$TARGET/scripts/RUN_V22_FROM_20K_TO_0P5.sh"
chmod +x "$TARGET/scripts/RUN_V22_FROM_ZERO_24H.sh"
chmod +x "$TARGET/scripts/RUN_V22_PREFLIGHT.sh"
chmod +x "$TARGET/v22/"*.py
chmod +x "$TARGET/v22/tools/"*.sh

echo "Installed v22 into: $TARGET"
echo "Next: cd '$TARGET' && ./scripts/RUN_V22_PREFLIGHT.sh"
