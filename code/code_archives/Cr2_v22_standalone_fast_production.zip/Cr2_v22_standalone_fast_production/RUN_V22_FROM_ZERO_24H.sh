#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PACKAGE_ROOT="$( cd "$SCRIPT_DIR/.." && pwd )"
cd "$PACKAGE_ROOT"

CONFIG="${CONFIG:-$PACKAGE_ROOT/v22/configs/v22_from_zero_24h.json}"
DRIVER="${DRIVER:-$PACKAGE_ROOT/v22/v22_controller.py}"
ENGINE="${ENGINE:-$PACKAGE_ROOT/engines/cas12/cr2_v1433_cas12_adaptive.py}"
OUTPUT_ROOT="${OUTPUT_ROOT:-$PACKAGE_ROOT/v22_runs/from_zero_24h_$(date +%Y%m%d_%H%M%S)}"

RUN_FLAG=()
if [ "${RUN:-0}" = "1" ]; then
  RUN_FLAG=(--run)
else
  echo "Dry-run only. To execute: RUN=1 $0"
fi

python3 "$DRIVER" \
  --config "$CONFIG" \
  --engine "$ENGINE" \
  --output-root "$OUTPUT_ROOT" \
  "${RUN_FLAG[@]}"
