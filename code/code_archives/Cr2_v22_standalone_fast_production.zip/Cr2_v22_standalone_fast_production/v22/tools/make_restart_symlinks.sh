#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -ne 1 ]; then
  echo "Usage: $0 /path/to/checkpoint_dir"
  exit 1
fi
D="$1"
cd "$D"
DETS="$(ls selected_dets_final*.npy 2>/dev/null | tail -1 || true)"
COEFF="$(ls selected_coeff_final*.npy 2>/dev/null | tail -1 || true)"
if [ -z "$DETS" ] || [ -z "$COEFF" ]; then
  echo "Could not find selected_dets_final*.npy and selected_coeff_final*.npy in $D"
  exit 1
fi
ln -sf "$DETS" selected_dets_final.npy
ln -sf "$COEFF" selected_coeff_final.npy
ls -lah selected_dets_final.npy selected_coeff_final.npy
