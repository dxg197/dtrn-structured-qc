#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
find "$ROOT" -type f | grep -Ei 'selected_(dets|coeff).*\.npy$|checkpoint_rows|paper_summary|final.*json' | sort
