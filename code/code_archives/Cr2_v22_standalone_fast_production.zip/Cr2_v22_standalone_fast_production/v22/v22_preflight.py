#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
import subprocess
import sys


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--engine', required=True)
    ap.add_argument('--package-root', required=True)
    args = ap.parse_args()
    root = Path(args.package_root).resolve()
    engine = Path(args.engine).resolve()
    print(f'[preflight] package_root={root}')
    print(f'[preflight] engine={engine}')
    ok = True
    if not engine.is_file():
        print('[FAIL] engine missing')
        ok = False
    rot = root / 'engines/cas12/cr2_v1435_no_results/01_make_no/active_rotation_from_restart.npy'
    if rot.is_file():
        print(f'[OK] active rotation found: {rot}')
    else:
        print(f'[WARN] active rotation not found at expected path: {rot}')
    if engine.is_file():
        try:
            out = subprocess.run([sys.executable, str(engine), '--help'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=20).stdout
        except Exception as e:
            print(f'[WARN] engine --help failed: {e}')
            out = ''
        required = ['--casscf', '--restart-dets', '--restart-coeff', '--restart-energy', '--max-selected-dim', '--output-dir']
        for flag in required:
            if flag in out:
                print(f'[OK] help supports {flag}')
            else:
                print(f'[WARN] help does not show {flag}; the engine may still accept it, but verify dry-run command.')
    print('[preflight] Dry-run a v22 command before RUN=1. Real engine load must show 29717 terms.')
    return 0 if ok else 1

if __name__ == '__main__':
    raise SystemExit(main())
