#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import os
from pathlib import Path
import re
import shlex
import signal
import subprocess
import sys
import time
from typing import Any, Optional

E_REF = -2086.650833304065
EXPECTED_TERMS = 29717
BAD_TERMS = 29709

ENERGY_KEYS = ("E_var", "energy", "e_var", "final_energy", "E_var_Ha")
DIM_KEYS = ("selected_dim", "dim", "n_selected", "final_selected_dim")
GAP_KEYS = ("gap_mHa", "gap_vs_CASSCF_mHa", "abs_gap_mHa")
N_KEYS = ("N", "particle_number", "n_electrons")
SZ_KEYS = ("Sz", "S_z", "spin_z")
TERMS_KEYS = ("n_terms", "hamiltonian_terms", "pauli_terms")
BAD_PATH_MARKERS = ("restart_v214b_v1425compat", "step000_to15676", "step001_to15926")


def q(x: Any) -> str:
    return shlex.quote(str(x))


def gap_mha(e_var: float) -> float:
    return (float(e_var) - E_REF) * 1000.0


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def coalesce(d: dict, keys):
    for k in keys:
        if k in d and d[k] is not None:
            return d[k]
    for parent in ("final", "metadata", "summary", "result", "observables"):
        sub = d.get(parent)
        if isinstance(sub, dict):
            for k in keys:
                if k in sub and sub[k] is not None:
                    return sub[k]
    return None


def parse_summary(outdir: Path) -> dict:
    files = []
    files += sorted(outdir.glob("*final*.json"))
    files += sorted(outdir.glob("summary*.json"))
    files += sorted(outdir.glob("paper_summary*.json"))
    files += sorted(outdir.glob("*.json"))
    best: dict[str, Any] = {}
    for jp in files:
        try:
            d = load_json(jp)
        except Exception:
            continue
        e = coalesce(d, ENERGY_KEYS)
        if e is None:
            continue
        out: dict[str, Any] = {"source_json": str(jp), "E_var": float(e)}
        dim = coalesce(d, DIM_KEYS)
        if dim is not None:
            try:
                out["selected_dim"] = int(float(dim))
            except Exception:
                pass
        gap = coalesce(d, GAP_KEYS)
        if gap is not None:
            try:
                out["gap_mHa"] = float(gap)
            except Exception:
                pass
        nval = coalesce(d, N_KEYS)
        if nval is not None:
            try:
                out["N"] = float(nval)
            except Exception:
                pass
        sz = coalesce(d, SZ_KEYS)
        if sz is not None:
            try:
                out["Sz"] = float(sz)
            except Exception:
                pass
        terms = coalesce(d, TERMS_KEYS)
        if terms is not None:
            try:
                out["n_terms"] = int(float(terms))
            except Exception:
                pass
        meta = d.get("metadata") if isinstance(d.get("metadata"), dict) else {}
        rot = meta.get("active_rotation_tag") or d.get("active_rotation_tag")
        if rot:
            out["active_rotation_tag"] = str(rot)
        obs = d.get("observables")
        if isinstance(obs, dict):
            if "N" in obs:
                try:
                    out["N"] = float(obs["N"])
                except Exception:
                    pass
            if "Sz" in obs:
                try:
                    out["Sz"] = float(obs["Sz"])
                except Exception:
                    pass
        best = out

    for cp in sorted(outdir.glob("checkpoint_rows*.csv")) + sorted(outdir.glob("checkpoint_rows.csv")):
        try:
            rows = list(csv.DictReader(cp.open(newline="", encoding="utf-8")))
        except Exception:
            continue
        if not rows:
            continue
        row = rows[-1]
        e = row.get("E_var") or row.get("energy") or row.get("e_var")
        if e:
            best.setdefault("source_csv", str(cp))
            best["E_var"] = float(e)
            dim = row.get("selected_dim") or row.get("dim")
            if dim:
                best["selected_dim"] = int(float(dim))
            gap = row.get("gap_mHa") or row.get("gap_vs_CASSCF_mHa")
            if gap:
                best["gap_mHa"] = float(gap)
    if best and "gap_mHa" not in best:
        best["gap_mHa"] = gap_mha(best["E_var"])
    return best


def infer_dim_from_name(path: Path) -> Optional[int]:
    for pat in (r"to(\d{4,6})", r"dim(\d{4,6})", r"_(\d{4,6})\b", r"(\d{4,6})"):
        ms = re.findall(pat, path.name)
        if ms:
            return int(ms[-1])
    return None


def find_file_pair(chk: Path) -> tuple[Path, Path]:
    direct = (chk / "selected_dets_final.npy", chk / "selected_coeff_final.npy")
    if direct[0].exists() and direct[1].exists():
        return direct
    det_final = sorted(chk.glob("selected_dets_final*.npy"))
    coeff_final = sorted(chk.glob("selected_coeff_final*.npy"))
    if det_final and coeff_final:
        return det_final[-1], coeff_final[-1]

    def key(p: Path) -> int:
        nums = [int(x) for x in re.findall(r"\d+", p.name)]
        return nums[-1] if nums else -1

    dets = sorted(list(chk.glob("selected_dets_iter*_dim*.npy")), key=key)
    coeffs = sorted(list(chk.glob("selected_coeff_iter*_dim*.npy")), key=key)
    if dets and coeffs:
        return dets[-1], coeffs[-1]
    raise FileNotFoundError(f"No selected det/coeff npy pair found in {chk}")


def checkpoint_metadata(chk: Path, fallback_dim: int, fallback_gap: Optional[float]) -> dict:
    dets, coeff = find_file_pair(chk)
    s = parse_summary(chk)
    dim = int(s.get("selected_dim") or infer_dim_from_name(chk) or fallback_dim)
    if "E_var" in s:
        e = float(s["E_var"])
    elif fallback_gap is not None:
        e = E_REF + fallback_gap / 1000.0
    else:
        raise RuntimeError(f"Could not determine E_var for {chk}. Pass start_gap_mHa in config or use a checkpoint with summary JSON/CSV.")
    gap = float(s.get("gap_mHa", gap_mha(e)))
    return {"dir": chk, "dets": dets, "coeff": coeff, "dim": dim, "E_var": e, "gap_mHa": gap}


def validate_start(meta: dict, cfg: dict):
    min_dim = int(cfg.get("min_start_dim", 0))
    max_gap = float(cfg.get("max_start_gap_mHa", 999999))
    if meta["dim"] < min_dim:
        raise SystemExit(f"Refusing start dim {meta['dim']} < min_start_dim {min_dim}")
    if meta["gap_mHa"] > max_gap:
        raise SystemExit(f"Refusing start gap {meta['gap_mHa']:.6f} > max_start_gap_mHa {max_gap}")
    if any(m in str(meta["dir"]) for m in BAD_PATH_MARKERS):
        raise SystemExit(f"Refusing known bad start branch: {meta['dir']}")


def build_engine_cmd(engine: Path, step_cfg: dict, current: dict, outdir: Path, tag: str) -> list[str]:
    dim = int(current["dim"])
    add = int(step_cfg.get("add_per_iter", 500))
    next_dim = int(step_cfg.get("target_dim", dim + add))
    cmd = [
        sys.executable, str(engine),
        "--preset", step_cfg.get("preset", "Cr2_production"),
        "--spatial-blocks", step_cfg.get("spatial_blocks", "0-1,2-4,5-7,8-9,10-11"),
        "--proposal-mode", step_cfg.get("proposal_mode", "hybrid"),
        "--pauli-candidate-limit", str(step_cfg.get("pauli_candidate_limit", 13750)),
        "--max-excitation-rank", str(step_cfg.get("max_excitation_rank", 10)),
        "--max-global-select-rank", str(step_cfg.get("max_global_select_rank", step_cfg.get("max_excitation_rank", 10))),
        "--selector-mode", step_cfg.get("selector_mode", "en2_topk"),
        "--en2-score-mode", step_cfg.get("en2_score_mode", "hybrid"),
        "--max-important-selected", str(step_cfg.get("max_important_selected", 7000)),
        "--coeff-cutoff", str(step_cfg.get("coeff_cutoff", "1e-06")),
        "--iterations", str(step_cfg.get("iterations", 1)),
        "--add-per-iter", str(add),
        "--max-selected-dim", str(next_dim),
        "--checkpoints", str(next_dim),
        "--diagnostic-top-k", str(step_cfg.get("diagnostic_top_k", 120)),
        "--top-report", str(step_cfg.get("top_report", 40)),
        "--max-rank-fraction", str(step_cfg.get("max_rank_fraction", 0.28)),
        "--branch-label", tag,
        "--output-dir", str(outdir),
        "--tag", tag,
        "--casscf",
    ]
    if current.get("dets") and current.get("coeff"):
        cmd += [
            "--restart-dets", str(current["dets"]),
            "--restart-coeff", str(current["coeff"]),
            "--restart-energy", f"{float(current['E_var']):.16f}",
            "--skip-initial-solve",
        ]
    return cmd


def run_monitored(cmd: list[str], log_path: Path, expected_terms: int, bad_terms: int) -> int:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    print(" ".join(q(x) for x in cmd))
    seen_expected = False
    with log_path.open("w", encoding="utf-8") as log:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        assert proc.stdout is not None
        try:
            for line in proc.stdout:
                print(line, end="")
                log.write(line)
                log.flush()
                if f"{bad_terms} terms" in line or f"terms={bad_terms}" in line:
                    proc.send_signal(signal.SIGTERM)
                    raise RuntimeError(f"Wrong Hamiltonian detected in log: {bad_terms} terms")
                if f"{expected_terms} terms" in line or f"terms={expected_terms}" in line:
                    seen_expected = True
        finally:
            rc = proc.wait()
    if rc != 0:
        return rc
    if not seen_expected:
        raise RuntimeError(f"Did not see expected Hamiltonian term count {expected_terms} in log. Refusing to trust output.")
    return 0


def validate_output(summary: dict, previous: Optional[dict], cfg: dict):
    if not summary or "E_var" not in summary:
        raise RuntimeError("Could not parse E_var from output summary")
    e = float(summary["E_var"])
    gap = float(summary.get("gap_mHa", gap_mha(e)))
    if previous is not None:
        prev_e = float(previous["E_var"])
        prev_gap = float(previous["gap_mHa"])
        if e > prev_e + float(cfg.get("monotone_tol_Ha", 1e-10)):
            raise RuntimeError(f"Non-monotone E_var: previous {prev_e:.16f}, new {e:.16f}")
        if gap > prev_gap + 1e-6:
            raise RuntimeError(f"Gap worsened: previous {prev_gap:.12f}, new {gap:.12f}")
    if "N" in summary and abs(float(summary["N"]) - 12.0) > float(cfg.get("N_tol", 1e-5)):
        raise RuntimeError(f"N check failed: {summary['N']}")
    if "Sz" in summary and abs(float(summary["Sz"])) > float(cfg.get("Sz_tol", 1e-5)):
        raise RuntimeError(f"Sz check failed: {summary['Sz']}")
    if "n_terms" in summary and int(summary["n_terms"]) != int(cfg.get("expected_terms", EXPECTED_TERMS)):
        raise RuntimeError(f"Wrong term count in summary: {summary['n_terms']}")


def append_progress(path: Path, row: dict):
    fields = ["step", "phase", "dim", "E_var", "gap_mHa", "gain_mHa", "gain_per_kdet", "outdir", "elapsed_s", "timestamp"]
    exists = path.exists()
    with path.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        if not exists:
            w.writeheader()
        w.writerow({k: row.get(k, "") for k in fields})


def main() -> int:
    ap = argparse.ArgumentParser(description="Cr2 v22 standalone fast production controller")
    ap.add_argument("--config", required=True)
    ap.add_argument("--engine", required=True)
    ap.add_argument("--start-dir", default="")
    ap.add_argument("--output-root", required=True)
    ap.add_argument("--run", action="store_true")
    args = ap.parse_args()

    cfg = load_json(Path(args.config))
    engine = Path(args.engine).expanduser().resolve()
    if not engine.is_file():
        raise SystemExit(f"Missing engine: {engine}")

    outroot = Path(args.output_root).expanduser().resolve()
    outroot.mkdir(parents=True, exist_ok=True)
    (outroot / "v22_run_config.json").write_text(json.dumps(cfg, indent=2) + "\n", encoding="utf-8")
    progress = outroot / "v22_progress.csv"

    if args.start_dir:
        current = checkpoint_metadata(Path(args.start_dir).expanduser().resolve(), int(cfg.get("start_dim", 0)), cfg.get("start_gap_mHa"))
        validate_start(current, cfg)
    else:
        current = {"dir": None, "dets": None, "coeff": None, "dim": 0, "E_var": None, "gap_mHa": None}
        if not cfg.get("allow_from_zero", False):
            raise SystemExit("No --start-dir supplied and config does not allow from-zero mode")

    print("[v22] package controller")
    print(f"[v22] config={args.config}")
    print(f"[v22] engine={engine}")
    print(f"[v22] output={outroot}")
    if current["dir"]:
        print(f"[v22] start_dir={current['dir']}")
        print(f"[v22] dim={current['dim']} E={float(current['E_var']):.16f} gap={float(current['gap_mHa']):.12f} mHa")
    else:
        print("[v22] from-zero mode")
    print("[v22] required: --casscf and 29717-term Hamiltonian")

    t0 = time.time()
    target_gap = float(cfg.get("target_gap_mHa", 0.5))
    max_wall = float(cfg.get("walltime_seconds", 86400))
    max_dim = int(cfg.get("max_dim", 30000))
    recent: list[float] = []

    steps = cfg.get("schedule", [])
    step_index = 0
    while True:
        elapsed = time.time() - t0
        if elapsed > max_wall:
            print(f"[v22] walltime reached: {elapsed:.1f}s")
            break
        if current.get("gap_mHa") is not None and float(current["gap_mHa"]) <= target_gap:
            print(f"[v22] target reached: {float(current['gap_mHa']):.12f} mHa <= {target_gap}")
            break
        if current.get("dim") is not None and int(current["dim"]) >= max_dim:
            print(f"[v22] max_dim reached: {current['dim']}")
            break
        if step_index >= len(steps):
            print("[v22] schedule exhausted")
            break

        base = dict(steps[step_index])
        phase = base.get("phase", f"step{step_index}")
        dim = int(current.get("dim") or 0)

        # Dynamic plateau trigger for restart runs.
        if current.get("dets") and len(recent) >= 2 and all(x < float(cfg.get("plateau_gain_per_kdet", 0.05)) for x in recent[-2:]):
            probe = dict(cfg.get("unlock_probe", {}))
            if probe:
                base.update(probe)
                phase = "unlock_probe"
                print("[v22] plateau trigger: unlock probe")

        add = int(base.get("add_per_iter", 500))
        target_dim = int(base.get("target_dim", dim + add))
        if current.get("dets"):
            target_dim = min(target_dim, max_dim)
            if target_dim <= dim:
                step_index += 1
                continue
        outdir = outroot / f"step{step_index:03d}_{phase}_to{target_dim}"
        tag = f"v22_{step_index:03d}_{phase}_to{target_dim}"
        base["target_dim"] = target_dim
        cmd = build_engine_cmd(engine, base, current, outdir, tag)

        print("\n[command]")
        print(" ".join(q(x) for x in cmd))
        if not args.run:
            print("[dry-run] not executing. Add --run or set RUN=1 in wrapper.")
            return 0

        log_path = outdir / "v22_engine.log"
        rc = run_monitored(cmd, log_path, int(cfg.get("expected_terms", EXPECTED_TERMS)), int(cfg.get("bad_terms", BAD_TERMS)))
        if rc != 0:
            raise SystemExit(f"Engine failed with exit code {rc}")

        summary = parse_summary(outdir)
        validate_output(summary, current if current.get("E_var") is not None else None, cfg)
        new_e = float(summary["E_var"])
        new_gap = float(summary.get("gap_mHa", gap_mha(new_e)))
        new_dim = int(summary.get("selected_dim", target_dim))
        old_gap = float(current["gap_mHa"]) if current.get("gap_mHa") is not None else None
        old_dim = int(current["dim"] or 0)
        gain = (old_gap - new_gap) if old_gap is not None else 0.0
        gain_per_k = gain / max((new_dim - old_dim) / 1000.0, 1e-9) if old_gap is not None else 0.0
        append_progress(progress, {
            "step": step_index,
            "phase": phase,
            "dim": new_dim,
            "E_var": f"{new_e:.16f}",
            "gap_mHa": f"{new_gap:.12f}",
            "gain_mHa": f"{gain:.12f}",
            "gain_per_kdet": f"{gain_per_k:.12f}",
            "outdir": str(outdir),
            "elapsed_s": f"{time.time() - t0:.1f}",
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        })
        print(f"[v22] result dim={new_dim} gap={new_gap:.12f} gain/kdet={gain_per_k:.6f}")

        dets, coeff = find_file_pair(outdir)
        current = {"dir": outdir, "dets": dets, "coeff": coeff, "dim": new_dim, "E_var": new_e, "gap_mHa": new_gap}
        if old_gap is not None:
            recent.append(gain_per_k)
        step_index += 1

    print("\n[v22 done]")
    if current.get("E_var") is not None:
        print(f"final_dim={current['dim']}")
        print(f"final_E_var={float(current['E_var']):.16f}")
        print(f"final_gap_mHa={float(current['gap_mHa']):.12f}")
    print(f"progress_csv={progress}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
