# v22 design lessons from the archive review

## What works

1. Use the v14.35/v21.3 natural-orbital lineage.
2. Real production runs must load 29717 Pauli terms.
3. Include `--casscf` in the low-level engine command.
4. Use large rank-10 top-k/hybrid production steps for throughput.
5. Add rank-11/12 only as triggered unlock probes when the slope collapses.
6. Reject non-monotone variational energies immediately.

## What does not work

1. Any run that loads 29709 terms for the v21.3/v14.35 checkpoint lineage.
2. Chaining after a large variational jump.
3. Long default diversity/coupling microstep production.
4. Rebuilding/scoring too much for 100-det increments.
5. Treating PT2/EN2 as a paper-safe energy rather than a diagnostic.

## Why <0.5 mHa in 24 hours is possible but not guaranteed

From the known v21.3 20k endpoint the gap is about 1.102 mHa. At the late v21.3 slope,
brute force would require many thousands more determinants. Reaching <0.5 mHa in 24h likely
requires one of:

- rank-11/12 unlock;
- a better parent/block-focused candidate pool;
- larger accepted batches without quality collapse;
- incremental matrix/eigensolve engineering beyond current engine behavior.

v22 therefore runs fast rank-10 production by default and only switches to expensive probes after
low-slope evidence appears.
