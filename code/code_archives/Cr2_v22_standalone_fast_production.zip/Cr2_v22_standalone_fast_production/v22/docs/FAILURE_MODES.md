# Failure modes and stop conditions

Stop immediately if the log shows:

```text
29709 terms
```

The correct Hamiltonian path for this lineage must show:

```text
29717 terms
```

Stop if E_var worsens, if N deviates from 12, if Sz deviates from 0, or if the gap jumps by more than numerical noise.

Known bad branch markers:

```text
restart_v214b_v1425compat
step000_to15676
step001_to15926
```
