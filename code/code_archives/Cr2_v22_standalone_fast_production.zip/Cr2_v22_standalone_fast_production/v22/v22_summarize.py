#!/usr/bin/env python3
from __future__ import annotations
import csv, sys
from pathlib import Path

if len(sys.argv) != 2:
    print('Usage: python3 v22/v22_summarize.py v22_runs/<run_id>')
    raise SystemExit(1)
root = Path(sys.argv[1])
progress = root / 'v22_progress.csv'
if not progress.exists():
    print(f'Missing {progress}')
    raise SystemExit(1)
rows = list(csv.DictReader(progress.open()))
if not rows:
    print('No rows')
    raise SystemExit(0)
print(f'Run: {root}')
print(f'Steps: {len(rows)}')
print('Last row:')
for k, v in rows[-1].items():
    print(f'  {k}: {v}')
