#!/usr/bin/env bash
set -euo pipefail

# Cr2 v22 aggressive production run.
#
# Intended use:
#   Continue the best v21.3 20k Cr2 CAS(12,12) checkpoint to <0.5 mHa
#   within a 30,000-second walltime budget on Mac M1 if slope permits.
#
# Install from package root:
#   cp cr2_v22_aggressive_driver.py .
#   cp RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5.sh scripts/
#   chmod +x cr2_v22_aggressive_driver.py scripts/RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5.sh
#
# Dry run:
#   ./scripts/RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5.sh
#
# Real run:
#   RUN=1 ./scripts/RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5.sh

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PACKAGE_ROOT="$( cd "$SCRIPT_DIR/.." && pwd )"
cd "$PACKAGE_ROOT"

DRIVER="${DRIVER:-$PACKAGE_ROOT/cr2_v22_aggressive_driver.py}"

# Search root should contain the final v21.3 results/checkpoints.
ROOT="${ROOT:-$PACKAGE_ROOT}"

# Explicitly set START_DIR if autodetection does not find the v21.3 20k checkpoint.
START_DIR="${START_DIR:-}"

# Preferred engine: the CAS(12,12) v21.3/v14.33-compatible adaptive selected-CI engine.
ENGINE="${ENGINE:-$PACKAGE_ROOT/engines/cas12/cr2_v1433_cas12_adaptive.py}"

# Natural-orbital rotation from the v14.35/v21.1/v21.3 CAS(12,12) lineage.
ROTATION="${ROTATION:-$PACKAGE_ROOT/engines/cas12/cr2_v1435_no_results/01_make_no/active_rotation_from_restart.npy}"

TARGET_GAP_MHA="${TARGET_GAP_MHA:-0.5}"
MAX_DIM="${MAX_DIM:-30000}"
START_DIM="${START_DIM:-20000}"
WALLTIME_SECONDS="${WALLTIME_SECONDS:-30000}"

# Aggressive production defaults.
ADD_PER_STEP="${ADD_PER_STEP:-500}"
MAX_RANK="${MAX_RANK:-10}"
MAX_GLOBAL_SELECT_RANK="${MAX_GLOBAL_SELECT_RANK:-10}"
SELECTOR_MODE="${SELECTOR_MODE:-en2_topk}"
PROPOSAL_MODE="${PROPOSAL_MODE:-hybrid}"
EN2_SCORE_MODE="${EN2_SCORE_MODE:-clipped_abs}"
MAX_IMPORTANT_SELECTED="${MAX_IMPORTANT_SELECTED:-7000}"
PAULI_CANDIDATE_LIMIT="${PAULI_CANDIDATE_LIMIT:-8500}"
CANDIDATE_POOL_SIZE="${CANDIDATE_POOL_SIZE:-1500000}"
PARENT_TOPK="${PARENT_TOPK:-7000}"

# Unlock trigger if rank-10 production slope collapses.
PLATEAU_GAIN_PER_KDET="${PLATEAU_GAIN_PER_KDET:-0.05}"
UNLOCK_ADD_PER_STEP="${UNLOCK_ADD_PER_STEP:-250}"
UNLOCK_MAX_RANK="${UNLOCK_MAX_RANK:-12}"

OUTPUT_ROOT="${OUTPUT_ROOT:-$PACKAGE_ROOT/cr2_v22_aggressive_from20k_to0p5_$(date +%Y%m%d_%H%M%S)}"

echo "PACKAGE_ROOT=$PACKAGE_ROOT"
echo "DRIVER=$DRIVER"
echo "ROOT=$ROOT"
echo "START_DIR=$START_DIR"
echo "ENGINE=$ENGINE"
echo "ROTATION=$ROTATION"
echo "TARGET_GAP_MHA=$TARGET_GAP_MHA"
echo "MAX_DIM=$MAX_DIM"
echo "START_DIM=$START_DIM"
echo "WALLTIME_SECONDS=$WALLTIME_SECONDS"
echo "ADD_PER_STEP=$ADD_PER_STEP"
echo "OUTPUT_ROOT=$OUTPUT_ROOT"

[ -f "$DRIVER" ] || { echo "Missing driver: $DRIVER"; exit 1; }
[ -f "$ENGINE" ] || { echo "Missing engine: $ENGINE"; exit 1; }

RUN_FLAG=()
if [ "${RUN:-0}" = "1" ]; then
  RUN_FLAG=(--run)
else
  echo "Dry-run only. To execute: RUN=1 $0"
fi

START_ARGS=()
if [ -n "$START_DIR" ]; then
  START_ARGS=(--start-dir "$START_DIR")
fi

ROT_ARGS=()
if [ -f "$ROTATION" ]; then
  ROT_ARGS=(--rotation "$ROTATION")
else
  echo "Warning: rotation file not found at $ROTATION"
  echo "The engine must still use the v14.35/v21.3 natural-orbital Hamiltonian basis."
fi

python3 "$DRIVER" \
  --root "$ROOT" \
  --engine "$ENGINE" \
  "${START_ARGS[@]}" \
  "${ROT_ARGS[@]}" \
  --start-dim "$START_DIM" \
  --target-gap-mha "$TARGET_GAP_MHA" \
  --max-dim "$MAX_DIM" \
  --walltime-seconds "$WALLTIME_SECONDS" \
  --add-per-step "$ADD_PER_STEP" \
  --max-rank "$MAX_RANK" \
  --max-global-select-rank "$MAX_GLOBAL_SELECT_RANK" \
  --selector-mode "$SELECTOR_MODE" \
  --proposal-mode "$PROPOSAL_MODE" \
  --en2-score-mode "$EN2_SCORE_MODE" \
  --max-important-selected "$MAX_IMPORTANT_SELECTED" \
  --pauli-candidate-limit "$PAULI_CANDIDATE_LIMIT" \
  --candidate-pool-size "$CANDIDATE_POOL_SIZE" \
  --parent-topk "$PARENT_TOPK" \
  --plateau-gain-per-kdet "$PLATEAU_GAIN_PER_KDET" \
  --unlock-add-per-step "$UNLOCK_ADD_PER_STEP" \
  --unlock-max-rank "$UNLOCK_MAX_RANK" \
  --output-root "$OUTPUT_ROOT" \
  "${RUN_FLAG[@]}"
