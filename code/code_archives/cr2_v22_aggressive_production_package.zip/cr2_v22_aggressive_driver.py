#!/usr/bin/env python3
"""
Cr2 v22 aggressive production restart driver.

Goal:
  Continue Cr2 CAS(12,12) from the best v21.3 20k checkpoint to <0.5 mHa
  as fast as possible on a Mac M1, while refusing to chain non-monotone or
  basis-mismatched checkpoints.

Design:
  - Default path: v21.3-style production continuation.
  - Rank 10, top-k / clipped_abs, large batches.
  - Minimal diagnostics in production.
  - Trigger rank 11/12 unlock probes only if slope collapses.
  - Preserve natural-orbital provenance active_rotation:c65788197e7dc63e.

This wrapper does not replace the chemistry engine. It orchestrates the
existing CAS(12,12) selected-CI engine that exposes the v14.33/v21.3-compatible
CLI:
  --restart-dets
  --restart-coeff
  --restart-energy
  --max-selected-dim
  --output-dir

Expected v21.3 20k start:
  selected_dim ~ 20000
  gap ~ 1.10 mHa
  E_ref = -2086.650833304065 Ha
  n_qubits = 24
  N = 12
  Sz = 0
  active_rotation:c65788197e7dc63e
"""

from __future__ import annotations

import argparse
import csv
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time
from typing import Optional, Tuple

E_REF = -2086.650833304065
EXPECTED_ROTATION_TAG = "active_rotation:c65788197e7dc63e"
EXPECTED_TERMS = 29717

ENERGY_KEYS = ("E_var", "energy", "e_var", "final_energy", "E_var_Ha")
DIM_KEYS = ("selected_dim", "dim", "n_selected", "final_selected_dim")
GAP_KEYS = ("gap_mHa", "gap_vs_CASSCF_mHa", "abs_gap_mHa")
N_KEYS = ("N", "particle_number", "n_electrons")
SZ_KEYS = ("Sz", "S_z", "spin_z")
TERMS_KEYS = ("n_terms", "hamiltonian_terms", "pauli_terms")

def q(x) -> str:
    return shlex.quote(str(x))

def gap_mha(e: float) -> float:
    return (float(e) - E_REF) * 1000.0

def read_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)

def coalesce(d: dict, keys):
    for k in keys:
        if k in d and d[k] is not None:
            return d[k]
    # Also check final/metadata subdicts used by some scripts.
    for parent in ("final", "metadata", "summary", "result"):
        sub = d.get(parent)
        if isinstance(sub, dict):
            for k in keys:
                if k in sub and sub[k] is not None:
                    return sub[k]
    return None

def parse_summary(outdir: Path) -> dict:
    candidates = []
    candidates += sorted(outdir.glob("*final.json"))
    candidates += sorted(outdir.glob("summary*.json"))
    candidates += sorted(outdir.glob("paper_summary*.json"))
    candidates += sorted(outdir.glob("*.json"))

    best = {}
    for jp in candidates:
        try:
            d = read_json(jp)
        except Exception:
            continue
        e = coalesce(d, ENERGY_KEYS)
        if e is None:
            continue
        out = {"source_json": str(jp), "E_var": float(e)}
        dim = coalesce(d, DIM_KEYS)
        if dim is not None:
            try: out["selected_dim"] = int(float(dim))
            except Exception: pass
        gap = coalesce(d, GAP_KEYS)
        if gap is not None:
            try: out["gap_mHa"] = float(gap)
            except Exception: pass
        nval = coalesce(d, N_KEYS)
        if nval is not None:
            try: out["N"] = float(nval)
            except Exception: pass
        sz = coalesce(d, SZ_KEYS)
        if sz is not None:
            try: out["Sz"] = float(sz)
            except Exception: pass
        terms = coalesce(d, TERMS_KEYS)
        if terms is not None:
            try: out["n_terms"] = int(float(terms))
            except Exception: pass
        meta = d.get("metadata") if isinstance(d.get("metadata"), dict) else d
        rot = meta.get("active_rotation_tag") if isinstance(meta, dict) else None
        if rot:
            out["active_rotation_tag"] = str(rot)
        best = out

    # CSV fallback.
    for cp in sorted(outdir.glob("checkpoint_rows.csv")):
        try:
            with cp.open(newline="", encoding="utf-8") as f:
                rows = list(csv.DictReader(f))
        except Exception:
            continue
        if rows:
            row = rows[-1]
            e = row.get("E_var") or row.get("energy") or row.get("e_var")
            if e:
                best.setdefault("source_csv", str(cp))
                best["E_var"] = float(e)
                dim = row.get("selected_dim") or row.get("dim")
                if dim:
                    best["selected_dim"] = int(float(dim))
                if "gap_mHa" in row and row["gap_mHa"]:
                    best["gap_mHa"] = float(row["gap_mHa"])
    if best and "gap_mHa" not in best:
        best["gap_mHa"] = gap_mha(best["E_var"])
    return best

def find_best_checkpoint(root: Path, preferred_dim: int) -> Path:
    # Prefer directories containing the target dimension and final restart files.
    candidates = []
    for p in root.rglob("*"):
        if not p.is_dir():
            continue
        if not (p / "selected_dets_final.npy").exists():
            continue
        if not (p / "selected_coeff_final.npy").exists():
            continue
        s = parse_summary(p)
        dim = s.get("selected_dim")
        if dim is None:
            m = re.search(r"to(\d+)|_(\d{5})\b|(\d{5})", p.name)
            if m:
                nums = [g for g in m.groups() if g]
                if nums:
                    dim = int(nums[-1])
        if dim is None:
            continue
        e = s.get("E_var")
        gap = s.get("gap_mHa")
        score = (abs(int(dim) - preferred_dim), -int(dim), float(gap) if gap is not None else 9999.0)
        candidates.append((score, p, s))
    if not candidates:
        raise FileNotFoundError(f"No checkpoint with selected_dets_final.npy/selected_coeff_final.npy found below {root}")
    candidates.sort(key=lambda x: x[0])
    return candidates[0][1]

def find_restart_files(chk: Path, fallback_dim: int, fallback_gap: Optional[float]) -> Tuple[Path, Path, float, int, float]:
    dets = chk / "selected_dets_final.npy"
    coeff = chk / "selected_coeff_final.npy"
    if not dets.exists():
        raise FileNotFoundError(f"Missing {dets}")
    if not coeff.exists():
        raise FileNotFoundError(f"Missing {coeff}")
    s = parse_summary(chk)
    dim = int(s.get("selected_dim") or fallback_dim)
    if "E_var" in s:
        e = float(s["E_var"])
    elif fallback_gap is not None:
        e = E_REF + float(fallback_gap) / 1000.0
    else:
        raise RuntimeError(f"Could not determine E_var for checkpoint {chk}; pass --start-energy or --start-gap-mha")
    gap = float(s.get("gap_mHa", gap_mha(e)))
    return dets, coeff, e, dim, gap

def validate_summary(s: dict, previous_e: float, previous_gap: float, strict_terms: bool) -> None:
    if not s:
        raise RuntimeError("No summary parsed from engine output")
    if "E_var" not in s:
        raise RuntimeError("No E_var parsed from engine output")
    e = float(s["E_var"])
    g = float(s.get("gap_mHa", gap_mha(e)))

    if e > previous_e + 1e-10:
        raise RuntimeError(f"Non-monotone E_var: previous {previous_e:.16f}, new {e:.16f}")
    if g > previous_gap + 1e-6:
        raise RuntimeError(f"Gap worsened: previous {previous_gap:.12f} mHa, new {g:.12f} mHa")

    if "N" in s and abs(float(s["N"]) - 12.0) > 1e-5:
        raise RuntimeError(f"Particle number check failed: N={s['N']}")
    if "Sz" in s and abs(float(s["Sz"])) > 1e-5:
        raise RuntimeError(f"Sz check failed: Sz={s['Sz']}")

    if strict_terms and "n_terms" in s and int(s["n_terms"]) != EXPECTED_TERMS:
        raise RuntimeError(f"Pauli term check failed: {s['n_terms']} != {EXPECTED_TERMS}")

    rot = s.get("active_rotation_tag")
    if rot and EXPECTED_ROTATION_TAG not in rot:
        raise RuntimeError(f"Active rotation tag check failed: {rot}")

def engine_help(engine: Path) -> str:
    try:
        r = subprocess.run([sys.executable, str(engine), "--help"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=20)
        return r.stdout
    except Exception:
        return ""

def add_if_supported(cmd: list[str], help_text: str, flag: str, value: Optional[str | int | float] = None) -> None:
    if flag in help_text:
        cmd.append(flag)
        if value is not None:
            cmd.append(str(value))

def make_command(args, engine: Path, dets: Path, coeff: Path, e: float, next_dim: int, outdir: Path, phase: str) -> list[str]:
    help_text = engine_help(engine)
    cmd = [
        sys.executable, str(engine),
        "--restart-dets", str(dets),
        "--restart-coeff", str(coeff),
        "--restart-energy", f"{e:.16f}",
        "--skip-initial-solve",
        "--initial-rank", str(args.initial_rank),
        "--selector-mode", args.selector_mode,
        "--max-excitation-rank", str(args.max_rank),
        "--max-global-select-rank", str(args.max_global_select_rank),
        "--allow-all-generated-ranks",
        "--min-select-rank", str(args.min_select_rank),
        "--max-rank-fraction", str(args.max_rank_fraction),
        "--max-selected-dim", str(next_dim),
        "--coeff-cutoff", str(args.coeff_cutoff),
        "--max-important-selected", str(args.max_important_selected),
        "--output-dir", str(outdir),
    ]

    # Optional v21.3/v21.4b flags, only if supported by the selected engine.
    optional_pairs = [
        ("--proposal-mode", args.proposal_mode),
        ("--en2-score-mode", args.en2_score_mode),
        ("--pauli-candidate-limit", args.pauli_candidate_limit),
        ("--candidate-pool-size", args.candidate_pool_size),
        ("--parent-topk", args.parent_topk),
        ("--diagnostic-every", args.diagnostic_every),
        ("--active-rotation", args.rotation),
        ("--rotation", args.rotation),
    ]
    for flag, value in optional_pairs:
        if value not in (None, "") and flag in help_text:
            cmd.extend([flag, str(value)])

    if phase == "unlock":
        # Prefer rank 11/12 probe when the engine supports rank args.
        pass

    return cmd

def append_run_log(log_path: Path, row: dict) -> None:
    exists = log_path.exists()
    fields = ["step","phase","dim","E_var","gap_mHa","gain_mHa","gain_per_kdet","outdir","timestamp"]
    with log_path.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        if not exists:
            w.writeheader()
        w.writerow({k: row.get(k, "") for k in fields})

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".", help="Search root containing v21.3/v21.4b results")
    ap.add_argument("--engine", required=True, help="CAS(12,12) selected-CI engine")
    ap.add_argument("--start-dir", default="", help="Explicit 20k checkpoint dir")
    ap.add_argument("--start-dim", type=int, default=20000)
    ap.add_argument("--start-gap-mha", type=float, default=None)
    ap.add_argument("--start-energy", type=float, default=None)
    ap.add_argument("--target-gap-mha", type=float, default=0.5)
    ap.add_argument("--max-dim", type=int, default=30000)
    ap.add_argument("--walltime-seconds", type=int, default=30000)
    ap.add_argument("--add-per-step", type=int, default=500)
    ap.add_argument("--output-root", default="cr2_v22_aggressive_from20k")
    ap.add_argument("--rotation", default="", help="active_rotation_from_restart.npy")
    ap.add_argument("--run", action="store_true")

    # Production settings.
    ap.add_argument("--initial-rank", type=int, default=10)
    ap.add_argument("--selector-mode", default="en2_topk")
    ap.add_argument("--proposal-mode", default="hybrid")
    ap.add_argument("--en2-score-mode", default="clipped_abs")
    ap.add_argument("--max-rank", type=int, default=10)
    ap.add_argument("--max-global-select-rank", type=int, default=10)
    ap.add_argument("--min-select-rank", type=int, default=3)
    ap.add_argument("--max-rank-fraction", type=float, default=0.45)
    ap.add_argument("--coeff-cutoff", default="1e-10")
    ap.add_argument("--max-important-selected", type=int, default=7000)
    ap.add_argument("--pauli-candidate-limit", type=int, default=8500)
    ap.add_argument("--candidate-pool-size", type=int, default=1500000)
    ap.add_argument("--parent-topk", type=int, default=7000)
    ap.add_argument("--diagnostic-every", type=int, default=3)

    # Unlock trigger.
    ap.add_argument("--plateau-gain-per-kdet", type=float, default=0.05,
                    help="Trigger unlock probe below this mHa/kdet")
    ap.add_argument("--unlock-add-per-step", type=int, default=250)
    ap.add_argument("--unlock-max-rank", type=int, default=12)
    ap.add_argument("--strict-terms", action="store_true")
    args = ap.parse_args()

    root = Path(args.root).expanduser().resolve()
    engine = Path(args.engine).expanduser().resolve()
    if not engine.is_file():
        raise SystemExit(f"Missing engine: {engine}")

    start_time = time.time()
    if args.start_dir:
        chk = Path(args.start_dir).expanduser().resolve()
    else:
        chk = find_best_checkpoint(root, args.start_dim)
    if not chk.is_dir():
        raise SystemExit(f"Missing start checkpoint: {chk}")

    dets, coeff, e, dim, gap = find_restart_files(chk, args.start_dim, args.start_gap_mha)
    if args.start_energy is not None:
        e = float(args.start_energy)
        gap = gap_mha(e)

    run_root = Path(args.output_root).expanduser().resolve()
    run_root.mkdir(parents=True, exist_ok=True)
    log_path = run_root / "v22_progress.csv"

    print("[v22] aggressive Cr2 CAS(12,12) production restart")
    print(f"[v22] root       = {root}")
    print(f"[v22] engine     = {engine}")
    print(f"[v22] start_dir  = {chk}")
    print(f"[v22] start_dim  = {dim}")
    print(f"[v22] start_E    = {e:.16f}")
    print(f"[v22] start_gap  = {gap:.12f} mHa")
    print(f"[v22] target_gap = {args.target_gap_mha:.6f} mHa")
    print(f"[v22] max_dim    = {args.max_dim}")
    print(f"[v22] walltime   = {args.walltime_seconds} s")
    print(f"[v22] output     = {run_root}")

    step = 0
    recent_gains = []

    while gap > args.target_gap_mha and dim < args.max_dim:
        elapsed = time.time() - start_time
        if elapsed > args.walltime_seconds:
            print(f"[v22] walltime reached: {elapsed:.1f}s > {args.walltime_seconds}s")
            break

        phase = "production"
        add = args.add_per_step
        max_rank_orig = args.max_rank
        max_global_orig = args.max_global_select_rank

        if len(recent_gains) >= 2 and all(g < args.plateau_gain_per_kdet for g in recent_gains[-2:]):
            phase = "unlock"
            add = args.unlock_add_per_step
            args.max_rank = args.unlock_max_rank
            args.max_global_select_rank = args.unlock_max_rank
            print(f"[v22] plateau trigger: recent gains {recent_gains[-2:]}; switching to unlock probe")

        next_dim = min(dim + add, args.max_dim)
        outdir = run_root / f"step{step:03d}_{phase}_to{next_dim}"
        outdir.mkdir(parents=True, exist_ok=True)

        cmd = make_command(args, engine, dets, coeff, e, next_dim, outdir, phase)

        # Restore args after command construction.
        args.max_rank = max_rank_orig
        args.max_global_select_rank = max_global_orig

        print("\n[command]")
        print(" ".join(q(x) for x in cmd))

        if not args.run:
            print("[dry-run] Not executing. Add --run or use the shell wrapper with RUN=1.")
            return 0

        rc = subprocess.call(cmd)
        if rc != 0:
            raise SystemExit(f"Engine failed with exit code {rc}")

        s = parse_summary(outdir)
        validate_summary(s, e, gap, args.strict_terms)

        new_e = float(s["E_var"])
        new_gap = float(s.get("gap_mHa", gap_mha(new_e)))
        new_dim = int(s.get("selected_dim", next_dim))
        gain = gap - new_gap
        denom = max(new_dim - dim, 1) / 1000.0
        gain_per_k = gain / denom

        print(f"[v22] step result: dim={new_dim} E={new_e:.16f} gap={new_gap:.12f} gain={gain:.6f} mHa gain/kdet={gain_per_k:.6f}")

        append_run_log(log_path, {
            "step": step,
            "phase": phase,
            "dim": new_dim,
            "E_var": f"{new_e:.16f}",
            "gap_mHa": f"{new_gap:.12f}",
            "gain_mHa": f"{gain:.12f}",
            "gain_per_kdet": f"{gain_per_k:.12f}",
            "outdir": str(outdir),
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        })

        next_dets = outdir / "selected_dets_final.npy"
        next_coeff = outdir / "selected_coeff_final.npy"
        if not next_dets.exists() or not next_coeff.exists():
            raise RuntimeError(f"Missing restart files in {outdir}")

        dets, coeff = next_dets, next_coeff
        e, gap, dim = new_e, new_gap, new_dim
        recent_gains.append(gain_per_k)
        step += 1

    print("\n[v22 done]")
    print(f"final_dim={dim}")
    print(f"final_E_var={e:.16f}")
    print(f"final_gap_mHa={gap:.12f}")
    print(f"progress_csv={log_path}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
