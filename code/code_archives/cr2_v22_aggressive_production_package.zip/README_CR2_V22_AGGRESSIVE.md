# Cr2 v22 aggressive production restart

This package builds an aggressive v22 wrapper intended to continue the best v21.3 Cr2 CAS(12,12) 20k checkpoint to `<0.5 mHa`, with a walltime budget of 30,000 seconds.

## Design

v22 is deliberately production-first:

- rank-10 top-k EN2/clipped_abs continuation by default
- 500-det production steps
- minimal diagnostics
- monotone variational-energy safety checks
- particle/spin sanity checks when summaries expose `N` and `Sz`
- plateau trigger into rank-11/12 unlock probe only if the slope collapses
- refuses to chain non-monotone checkpoints

The goal is to make v21.4b behave more like the fast v21.3 path unless it actually needs an unlock.

## Install

From the package root:

```bash
unzip cr2_v22_aggressive_production_package.zip
cp cr2_v22_aggressive_driver.py .
cp RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5.sh scripts/
chmod +x cr2_v22_aggressive_driver.py scripts/RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5.sh
```

## Dry run

```bash
./scripts/RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5.sh
```

## Real run

```bash
RUN=1 ./scripts/RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5.sh
```

## If checkpoint autodetection fails

Point directly at the v21.3 20k checkpoint:

```bash
START_DIR="/path/to/v21.3/step_to20000" RUN=1 \
./scripts/RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5.sh
```

## Defaults

```text
START_DIM=20000
TARGET_GAP_MHA=0.5
MAX_DIM=30000
WALLTIME_SECONDS=30000
ADD_PER_STEP=500
MAX_RANK=10
MAX_GLOBAL_SELECT_RANK=10
SELECTOR_MODE=en2_topk
PROPOSAL_MODE=hybrid
EN2_SCORE_MODE=clipped_abs
MAX_IMPORTANT_SELECTED=7000
PAULI_CANDIDATE_LIMIT=8500
CANDIDATE_POOL_SIZE=1500000
PARENT_TOPK=7000
PLATEAU_GAIN_PER_KDET=0.05
UNLOCK_MAX_RANK=12
```

## Important

Use only a natural-orbital compatible Cr2 CAS(12,12) engine/checkpoint lineage:

```text
active_rotation:c65788197e7dc63e
E_ref = -2086.650833304065 Ha
N = 12
Sz = 0
```

Do not chain from runs that worsened variational energy or reinterpreted determinants in the wrong Hamiltonian basis.
