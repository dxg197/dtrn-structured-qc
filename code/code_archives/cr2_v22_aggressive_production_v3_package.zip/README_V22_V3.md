# Cr2 v22 aggressive production v3

v3 fixes the actual failure in v2.

The failed v2 run loaded:

```text
29709 Pauli terms
```

because it launched `cr2_v1433_cas12_adaptive.py` without `--casscf`. The known-good v21.3/v21.4b command pattern loads:

```text
29717 Pauli terms
active_rotation:c65788197e7dc63e
```

v3 forces that known-good command pattern:

```text
--casscf
--preset Cr2_production
--spatial-blocks 0-1,2-4,5-7,8-9,10-11
--iterations 1
--add-per-iter 500
--checkpoints NEXT_DIM
--en2-score-mode hybrid
--max-rank-fraction 0.28
--coeff-cutoff 1e-06
--pauli-candidate-limit 13750
```

## Install

```bash
unzip cr2_v22_aggressive_production_v3_package.zip
cp cr2_v22_aggressive_driver_v3.py .
cp RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5_V3.sh scripts/
chmod +x cr2_v22_aggressive_driver_v3.py scripts/RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5_V3.sh
```

## Dry run

```bash
START_DIR="$PWD/v21_3_final_results/step028_restart_r10_to20000" \
./scripts/RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5_V3.sh
```

The command must include `--casscf`.

## Real run

```bash
START_DIR="$PWD/v21_3_final_results/step028_restart_r10_to20000" RUN=1 \
./scripts/RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5_V3.sh
```

Discard outputs from the failed v2 run where the first real solve jumped to ~187 mHa.
