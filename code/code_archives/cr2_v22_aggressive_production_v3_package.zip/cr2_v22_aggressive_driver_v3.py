#!/usr/bin/env python3
"""
Cr2 v22 aggressive production driver, v3.

v3 fixes the failure seen in v2:
  - v2 launched cr2_v1433_cas12_adaptive.py without --casscf.
  - That loaded the 29709-term cache and reinterpreted the 20k NO checkpoint.
  - v3 forces the successful v21.3/v21.4b command pattern:
      --casscf
      --preset Cr2_production
      --spatial-blocks 0-1,2-4,5-7,8-9,10-11
      --iterations 1
      --add-per-iter 500
      --checkpoints NEXT_DIM
      --en2-score-mode hybrid
      --max-rank-fraction 0.28
      --coeff-cutoff 1e-06
      --pauli-candidate-limit 13750
  - v3 validates n_terms == 29717 and active_rotation:c65788197e7dc63e if present.

Use only with Cr2 CAS(12,12) natural-orbital/v21.3 checkpoint lineage.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time
from typing import Optional, Tuple

E_REF = -2086.650833304065
EXPECTED_TERMS = 29717
EXPECTED_ROTATION_TAG = "active_rotation:c65788197e7dc63e"

BAD_PATH_MARKERS = (
    "restart_v214b_v1425compat",
    "step000_to15676",
    "step001_to15926",
    "step002_to16176",
)

ENERGY_KEYS = ("E_var", "energy", "e_var", "final_energy", "E_var_Ha")
DIM_KEYS = ("selected_dim", "dim", "n_selected", "final_selected_dim")
GAP_KEYS = ("gap_mHa", "gap_vs_CASSCF_mHa", "abs_gap_mHa")
N_KEYS = ("N", "particle_number", "n_electrons")
SZ_KEYS = ("Sz", "S_z", "spin_z")
TERMS_KEYS = ("n_terms", "hamiltonian_terms", "pauli_terms")

def q(x) -> str:
    return shlex.quote(str(x))

def gap_mha(e: float) -> float:
    return (float(e) - E_REF) * 1000.0

def read_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)

def coalesce(d: dict, keys):
    for k in keys:
        if k in d and d[k] is not None:
            return d[k]
    for parent in ("final", "metadata", "summary", "result", "observables"):
        sub = d.get(parent)
        if isinstance(sub, dict):
            for k in keys:
                if k in sub and sub[k] is not None:
                    return sub[k]
    return None

def parse_summary(outdir: Path) -> dict:
    files = []
    files += sorted(outdir.glob("*final*.json"))
    files += sorted(outdir.glob("summary*.json"))
    files += sorted(outdir.glob("paper_summary*.json"))
    files += sorted(outdir.glob("*.json"))
    best = {}
    for jp in files:
        try:
            d = read_json(jp)
        except Exception:
            continue
        e = coalesce(d, ENERGY_KEYS)
        if e is None:
            continue
        out = {"source_json": str(jp), "E_var": float(e)}
        dim = coalesce(d, DIM_KEYS)
        if dim is not None:
            try: out["selected_dim"] = int(float(dim))
            except Exception: pass
        gap = coalesce(d, GAP_KEYS)
        if gap is not None:
            try: out["gap_mHa"] = float(gap)
            except Exception: pass
        nval = coalesce(d, N_KEYS)
        if nval is not None:
            try: out["N"] = float(nval)
            except Exception: pass
        sz = coalesce(d, SZ_KEYS)
        if sz is not None:
            try: out["Sz"] = float(sz)
            except Exception: pass
        terms = coalesce(d, TERMS_KEYS)
        if terms is not None:
            try: out["n_terms"] = int(float(terms))
            except Exception: pass
        meta = d.get("metadata") if isinstance(d.get("metadata"), dict) else {}
        rot = meta.get("active_rotation_tag") or d.get("active_rotation_tag")
        if rot:
            out["active_rotation_tag"] = str(rot)
        # Observables usually nested as {"N": ..., "Sz": ...}
        obs = d.get("observables")
        if isinstance(obs, dict):
            if "N" in obs:
                try: out["N"] = float(obs["N"])
                except Exception: pass
            if "Sz" in obs:
                try: out["Sz"] = float(obs["Sz"])
                except Exception: pass
        best = out

    # CSV fallback.
    for cp in sorted(outdir.glob("checkpoint_rows*.csv")) + sorted(outdir.glob("checkpoint_rows.csv")):
        try:
            with cp.open(newline="", encoding="utf-8") as f:
                rows = list(csv.DictReader(f))
        except Exception:
            continue
        if rows:
            row = rows[-1]
            e = row.get("E_var") or row.get("energy") or row.get("e_var")
            if e:
                best.setdefault("source_csv", str(cp))
                best["E_var"] = float(e)
                dim = row.get("selected_dim") or row.get("dim")
                if dim:
                    best["selected_dim"] = int(float(dim))
                gap = row.get("gap_mHa") or row.get("gap_vs_CASSCF_mHa")
                if gap:
                    best["gap_mHa"] = float(gap)
    if best and "gap_mHa" not in best:
        best["gap_mHa"] = gap_mha(best["E_var"])
    return best

def infer_dim_from_name(path: Path) -> Optional[int]:
    for pat in (r"to(\d{4,6})", r"dim(\d{4,6})", r"_(\d{4,6})\b", r"(\d{4,6})"):
        ms = re.findall(pat, path.name)
        if ms:
            return int(ms[-1])
    return None

def is_bad_path(path: Path) -> bool:
    s = str(path)
    return any(m in s for m in BAD_PATH_MARKERS)

def find_file_pair(chk: Path) -> Tuple[Path, Path]:
    dets = chk / "selected_dets_final.npy"
    coeff = chk / "selected_coeff_final.npy"
    if dets.exists() and coeff.exists():
        return dets, coeff

    det_candidates = sorted(chk.glob("selected_dets_final*.npy")) + sorted(chk.glob("selected_dets_iter*_dim*.npy"))
    coeff_candidates = sorted(chk.glob("selected_coeff_final*.npy")) + sorted(chk.glob("selected_coeff_iter*_dim*.npy"))

    # Prefer final files, then highest-dim iter files.
    det_final = sorted(chk.glob("selected_dets_final*.npy"))
    coeff_final = sorted(chk.glob("selected_coeff_final*.npy"))
    if det_final and coeff_final:
        return det_final[-1], coeff_final[-1]

    def key(p: Path):
        nums = [int(x) for x in re.findall(r"\d+", p.name)]
        return nums[-1] if nums else -1
    if det_candidates and coeff_candidates:
        return sorted(det_candidates, key=key)[-1], sorted(coeff_candidates, key=key)[-1]

    raise FileNotFoundError(f"Could not find selected_dets/selected_coeff files in {chk}")

def collect_checkpoints(root: Path):
    out = []
    for p in root.rglob("*"):
        if not p.is_dir():
            continue
        try:
            dets, coeff = find_file_pair(p)
        except Exception:
            continue
        s = parse_summary(p)
        dim = s.get("selected_dim") or infer_dim_from_name(p)
        e = s.get("E_var")
        gap = s.get("gap_mHa")
        if gap is None and e is not None:
            gap = gap_mha(e)
        out.append({
            "path": p,
            "dets": dets,
            "coeff": coeff,
            "dim": int(dim) if dim is not None else None,
            "E_var": float(e) if e is not None else None,
            "gap_mHa": float(gap) if gap is not None else None,
            "bad_marker": is_bad_path(p),
        })
    return out

def find_best_checkpoint(root: Path, preferred_dim: int, min_start_dim: int, max_start_gap_mha: float) -> Path:
    allc = collect_checkpoints(root)
    ok = []
    for c in allc:
        if c["bad_marker"]:
            continue
        dim = c["dim"]
        gap = c["gap_mHa"]
        if dim is None or dim < min_start_dim:
            continue
        if gap is not None and gap > max_start_gap_mha:
            continue
        ok.append(((abs(dim - preferred_dim), -dim, gap if gap is not None else 9999.0), c))
    if ok:
        ok.sort(key=lambda x: x[0])
        return ok[0][1]["path"]

    print("\n[v22-v3] No acceptable auto-detected checkpoint.")
    print(f"[v22-v3] Need dim >= {min_start_dim}, gap <= {max_start_gap_mha}, not known bad branch.")
    print("[v22-v3] Candidate checkpoints:")
    for c in sorted(allc, key=lambda x: (x["dim"] or -1, str(x["path"]))):
        print(f"  dim={c['dim']} gap={c['gap_mHa']} bad={c['bad_marker']} path={c['path']}")
    raise FileNotFoundError("No acceptable start checkpoint")

def find_restart_files(chk: Path, fallback_dim: int, fallback_gap: Optional[float]) -> Tuple[Path, Path, float, int, float]:
    dets, coeff = find_file_pair(chk)
    s = parse_summary(chk)
    dim = int(s.get("selected_dim") or infer_dim_from_name(chk) or fallback_dim)
    if "E_var" in s:
        e = float(s["E_var"])
    elif fallback_gap is not None:
        e = E_REF + fallback_gap / 1000.0
    else:
        raise RuntimeError(f"Could not determine E_var in {chk}; pass --start-gap-mha")
    gap = float(s.get("gap_mHa", gap_mha(e)))
    return dets, coeff, e, dim, gap

def build_cmd(args, engine: Path, dets: Path, coeff: Path, energy: float, next_dim: int, outdir: Path, step: int, phase: str):
    tag = f"v22_step{step:03d}_{phase}_to{next_dim}"
    return [
        sys.executable, str(engine),
        "--preset", "Cr2_production",
        "--spatial-blocks", "0-1,2-4,5-7,8-9,10-11",
        "--proposal-mode", args.proposal_mode,
        "--pauli-candidate-limit", str(args.pauli_candidate_limit),
        "--max-excitation-rank", str(args.max_rank),
        "--max-global-select-rank", str(args.max_global_select_rank),
        "--selector-mode", args.selector_mode,
        "--en2-score-mode", args.en2_score_mode,
        "--max-important-selected", str(args.max_important_selected),
        "--coeff-cutoff", str(args.coeff_cutoff),
        "--iterations", "1",
        "--add-per-iter", str(args.add_per_step if phase == "production" else args.unlock_add_per_step),
        "--max-selected-dim", str(next_dim),
        "--checkpoints", str(next_dim),
        "--diagnostic-top-k", str(args.diagnostic_top_k),
        "--top-report", str(args.top_report),
        "--max-rank-fraction", str(args.max_rank_fraction),
        "--branch-label", f"v22_{tag}",
        "--output-dir", str(outdir),
        "--tag", tag,
        "--casscf",
        "--restart-dets", str(dets),
        "--restart-coeff", str(coeff),
        "--restart-energy", f"{energy:.16f}",
        "--skip-initial-solve",
    ]

def validate_summary(s: dict, previous_e: float, previous_gap: float):
    if not s or "E_var" not in s:
        raise RuntimeError("Could not parse E_var from output")
    e = float(s["E_var"])
    g = float(s.get("gap_mHa", gap_mha(e)))
    if "n_terms" in s and int(s["n_terms"]) != EXPECTED_TERMS:
        raise RuntimeError(f"Wrong Hamiltonian term count: {s['n_terms']} != {EXPECTED_TERMS}")
    rot = s.get("active_rotation_tag")
    if rot and EXPECTED_ROTATION_TAG not in rot:
        raise RuntimeError(f"Wrong active rotation: {rot}")
    if e > previous_e + 1e-10:
        raise RuntimeError(f"Non-monotone E_var: previous {previous_e:.16f}, new {e:.16f}")
    if g > previous_gap + 1e-6:
        raise RuntimeError(f"Gap worsened: previous {previous_gap:.12f}, new {g:.12f}")
    if "N" in s and abs(float(s["N"]) - 12.0) > 1e-5:
        raise RuntimeError(f"N check failed: {s['N']}")
    if "Sz" in s and abs(float(s["Sz"])) > 1e-5:
        raise RuntimeError(f"Sz check failed: {s['Sz']}")

def append_log(path: Path, row: dict):
    fields = ["step", "phase", "dim", "E_var", "gap_mHa", "gain_mHa", "gain_per_kdet", "outdir", "timestamp"]
    exists = path.exists()
    with path.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        if not exists:
            w.writeheader()
        w.writerow({k: row.get(k, "") for k in fields})

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--engine", required=True)
    ap.add_argument("--start-dir", default="")
    ap.add_argument("--start-dim", type=int, default=20000)
    ap.add_argument("--min-start-dim", type=int, default=19500)
    ap.add_argument("--max-start-gap-mha", type=float, default=3.0)
    ap.add_argument("--start-gap-mha", type=float, default=None)
    ap.add_argument("--target-gap-mha", type=float, default=0.5)
    ap.add_argument("--max-dim", type=int, default=30000)
    ap.add_argument("--walltime-seconds", type=int, default=30000)
    ap.add_argument("--add-per-step", type=int, default=500)
    ap.add_argument("--output-root", default="cr2_v22_v3_from20k")
    ap.add_argument("--run", action="store_true")

    ap.add_argument("--selector-mode", default="en2_topk")
    ap.add_argument("--proposal-mode", default="hybrid")
    ap.add_argument("--en2-score-mode", default="hybrid")
    ap.add_argument("--max-rank", type=int, default=10)
    ap.add_argument("--max-global-select-rank", type=int, default=10)
    ap.add_argument("--max-rank-fraction", type=float, default=0.28)
    ap.add_argument("--coeff-cutoff", default="1e-06")
    ap.add_argument("--max-important-selected", type=int, default=7000)
    ap.add_argument("--pauli-candidate-limit", type=int, default=13750)
    ap.add_argument("--diagnostic-top-k", type=int, default=120)
    ap.add_argument("--top-report", type=int, default=40)
    ap.add_argument("--plateau-gain-per-kdet", type=float, default=0.05)
    ap.add_argument("--unlock-add-per-step", type=int, default=250)
    ap.add_argument("--unlock-max-rank", type=int, default=12)
    args = ap.parse_args()

    root = Path(args.root).expanduser().resolve()
    engine = Path(args.engine).expanduser().resolve()
    if not engine.is_file():
        raise SystemExit(f"Missing engine: {engine}")

    if args.start_dir:
        chk = Path(args.start_dir).expanduser().resolve()
        if not chk.is_dir():
            raise SystemExit(f"Missing START_DIR: {chk}")
    else:
        chk = find_best_checkpoint(root, args.start_dim, args.min_start_dim, args.max_start_gap_mha)

    dets, coeff, e, dim, gap = find_restart_files(chk, args.start_dim, args.start_gap_mha)
    if dim < args.min_start_dim or gap > args.max_start_gap_mha:
        raise SystemExit(f"Refusing checkpoint dim={dim}, gap={gap:.6f} mHa")

    outroot = Path(args.output_root).expanduser().resolve()
    outroot.mkdir(parents=True, exist_ok=True)
    log = outroot / "v22_v3_progress.csv"

    print("[v22-v3] Cr2 CAS(12,12) aggressive v21.3-compatible continuation")
    print(f"[v22-v3] start_dir={chk}")
    print(f"[v22-v3] dets={dets}")
    print(f"[v22-v3] coeff={coeff}")
    print(f"[v22-v3] dim={dim}")
    print(f"[v22-v3] E={e:.16f}")
    print(f"[v22-v3] gap={gap:.12f} mHa")
    print(f"[v22-v3] target={args.target_gap_mha:.6f} mHa")
    print(f"[v22-v3] output={outroot}")
    print("[v22-v3] required command features: --casscf, 29717-term Hamiltonian, active_rotation:c65788197e7dc63e")

    recent = []
    step = 0
    t0 = time.time()

    while gap > args.target_gap_mha and dim < args.max_dim:
        if time.time() - t0 > args.walltime_seconds:
            print("[v22-v3] walltime reached")
            break

        phase = "production"
        add = args.add_per_step
        old_rank, old_global = args.max_rank, args.max_global_select_rank
        if len(recent) >= 2 and all(x < args.plateau_gain_per_kdet for x in recent[-2:]):
            phase = "unlock"
            args.max_rank = args.unlock_max_rank
            args.max_global_select_rank = args.unlock_max_rank
            add = args.unlock_add_per_step
            print("[v22-v3] plateau trigger: rank-11/12 unlock probe")

        next_dim = min(dim + add, args.max_dim)
        outdir = outroot / f"step{step:03d}_{phase}_to{next_dim}"
        outdir.mkdir(parents=True, exist_ok=True)

        cmd = build_cmd(args, engine, dets, coeff, e, next_dim, outdir, step, phase)
        args.max_rank, args.max_global_select_rank = old_rank, old_global

        print("\n[command]")
        print(" ".join(q(x) for x in cmd))
        if not args.run:
            print("[dry-run] not executing. Use RUN=1 in shell wrapper or --run.")
            return 0

        rc = subprocess.call(cmd)
        if rc != 0:
            raise SystemExit(f"Engine failed with exit code {rc}")

        s = parse_summary(outdir)
        validate_summary(s, e, gap)
        new_e = float(s["E_var"])
        new_gap = float(s.get("gap_mHa", gap_mha(new_e)))
        new_dim = int(s.get("selected_dim", next_dim))
        gain = gap - new_gap
        gain_per_k = gain / max((new_dim - dim) / 1000.0, 1e-9)

        print(f"[v22-v3] result dim={new_dim} gap={new_gap:.12f} gain/kdet={gain_per_k:.6f}")

        append_log(log, {
            "step": step, "phase": phase, "dim": new_dim, "E_var": f"{new_e:.16f}",
            "gap_mHa": f"{new_gap:.12f}", "gain_mHa": f"{gain:.12f}",
            "gain_per_kdet": f"{gain_per_k:.12f}", "outdir": str(outdir),
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
        })

        nd, nc = find_file_pair(outdir)
        dets, coeff, e, gap, dim = nd, nc, new_e, new_gap, new_dim
        recent.append(gain_per_k)
        step += 1

    print("\n[v22-v3 done]")
    print(f"final_dim={dim}")
    print(f"final_E_var={e:.16f}")
    print(f"final_gap_mHa={gap:.12f}")
    print(f"progress_csv={log}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
