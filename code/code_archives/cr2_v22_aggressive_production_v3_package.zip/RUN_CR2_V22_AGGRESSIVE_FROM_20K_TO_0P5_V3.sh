#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PACKAGE_ROOT="$( cd "$SCRIPT_DIR/.." && pwd )"
cd "$PACKAGE_ROOT"

DRIVER="${DRIVER:-$PACKAGE_ROOT/cr2_v22_aggressive_driver_v3.py}"
ROOT="${ROOT:-$PACKAGE_ROOT}"
START_DIR="${START_DIR:-}"
ENGINE="${ENGINE:-$PACKAGE_ROOT/engines/cas12/cr2_v1433_cas12_adaptive.py}"

TARGET_GAP_MHA="${TARGET_GAP_MHA:-0.5}"
MAX_DIM="${MAX_DIM:-30000}"
START_DIM="${START_DIM:-20000}"
MIN_START_DIM="${MIN_START_DIM:-19500}"
MAX_START_GAP_MHA="${MAX_START_GAP_MHA:-3.0}"
WALLTIME_SECONDS="${WALLTIME_SECONDS:-30000}"
ADD_PER_STEP="${ADD_PER_STEP:-500}"
OUTPUT_ROOT="${OUTPUT_ROOT:-$PACKAGE_ROOT/cr2_v22_v3_from20k_to0p5_$(date +%Y%m%d_%H%M%S)}"

echo "PACKAGE_ROOT=$PACKAGE_ROOT"
echo "DRIVER=$DRIVER"
echo "ROOT=$ROOT"
echo "START_DIR=$START_DIR"
echo "ENGINE=$ENGINE"
echo "TARGET_GAP_MHA=$TARGET_GAP_MHA"
echo "OUTPUT_ROOT=$OUTPUT_ROOT"

[ -f "$DRIVER" ] || { echo "Missing driver: $DRIVER"; exit 1; }
[ -f "$ENGINE" ] || { echo "Missing engine: $ENGINE"; exit 1; }

RUN_FLAG=()
if [ "${RUN:-0}" = "1" ]; then
  RUN_FLAG=(--run)
else
  echo "Dry-run only. To execute: RUN=1 $0"
fi

START_ARGS=()
if [ -n "$START_DIR" ]; then
  START_ARGS=(--start-dir "$START_DIR")
fi

python3 "$DRIVER" \
  --root "$ROOT" \
  --engine "$ENGINE" \
  "${START_ARGS[@]}" \
  --start-dim "$START_DIM" \
  --min-start-dim "$MIN_START_DIM" \
  --max-start-gap-mha "$MAX_START_GAP_MHA" \
  --target-gap-mha "$TARGET_GAP_MHA" \
  --max-dim "$MAX_DIM" \
  --walltime-seconds "$WALLTIME_SECONDS" \
  --add-per-step "$ADD_PER_STEP" \
  --output-root "$OUTPUT_ROOT" \
  "${RUN_FLAG[@]}"
