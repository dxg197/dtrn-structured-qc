#!/usr/bin/env python3
"""
Cr2 v22 aggressive production restart driver, v2.

Fix relative to v1:
  - Refuses to auto-start from corrupted high-gap branches such as
    restart_v214b_v1425compat_*.
  - Requires autodetected start checkpoint to be near START_DIM and below
    MAX_START_GAP_MHA.
  - Prints candidate checkpoints when no acceptable 20k checkpoint is found.

Use START_DIR explicitly if the v21.3 20k checkpoint is outside this package.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time
from typing import Optional, Tuple

E_REF = -2086.650833304065
EXPECTED_ROTATION_TAG = "active_rotation:c65788197e7dc63e"

BAD_PATH_MARKERS = (
    "restart_v214b_v1425compat",
    "step000_to15676",
    "step001_to15926",
    "step002_to16176",
)

ENERGY_KEYS = ("E_var", "energy", "e_var", "final_energy", "E_var_Ha")
DIM_KEYS = ("selected_dim", "dim", "n_selected", "final_selected_dim")
GAP_KEYS = ("gap_mHa", "gap_vs_CASSCF_mHa", "abs_gap_mHa")
N_KEYS = ("N", "particle_number", "n_electrons")
SZ_KEYS = ("Sz", "S_z", "spin_z")
TERMS_KEYS = ("n_terms", "hamiltonian_terms", "pauli_terms")

def q(x) -> str:
    return shlex.quote(str(x))

def gap_mha(e: float) -> float:
    return (float(e) - E_REF) * 1000.0

def read_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)

def coalesce(d: dict, keys):
    for k in keys:
        if k in d and d[k] is not None:
            return d[k]
    for parent in ("final", "metadata", "summary", "result"):
        sub = d.get(parent)
        if isinstance(sub, dict):
            for k in keys:
                if k in sub and sub[k] is not None:
                    return sub[k]
    return None

def parse_summary(outdir: Path) -> dict:
    candidates = []
    candidates += sorted(outdir.glob("*final.json"))
    candidates += sorted(outdir.glob("summary*.json"))
    candidates += sorted(outdir.glob("paper_summary*.json"))
    candidates += sorted(outdir.glob("*.json"))

    best = {}
    for jp in candidates:
        try:
            d = read_json(jp)
        except Exception:
            continue
        e = coalesce(d, ENERGY_KEYS)
        if e is None:
            continue
        out = {"source_json": str(jp), "E_var": float(e)}
        dim = coalesce(d, DIM_KEYS)
        if dim is not None:
            try:
                out["selected_dim"] = int(float(dim))
            except Exception:
                pass
        gap = coalesce(d, GAP_KEYS)
        if gap is not None:
            try:
                out["gap_mHa"] = float(gap)
            except Exception:
                pass
        nval = coalesce(d, N_KEYS)
        if nval is not None:
            try:
                out["N"] = float(nval)
            except Exception:
                pass
        sz = coalesce(d, SZ_KEYS)
        if sz is not None:
            try:
                out["Sz"] = float(sz)
            except Exception:
                pass
        terms = coalesce(d, TERMS_KEYS)
        if terms is not None:
            try:
                out["n_terms"] = int(float(terms))
            except Exception:
                pass
        meta = d.get("metadata") if isinstance(d.get("metadata"), dict) else d
        rot = meta.get("active_rotation_tag") if isinstance(meta, dict) else None
        if rot:
            out["active_rotation_tag"] = str(rot)
        best = out

    for cp in sorted(outdir.glob("checkpoint_rows.csv")):
        try:
            with cp.open(newline="", encoding="utf-8") as f:
                rows = list(csv.DictReader(f))
        except Exception:
            continue
        if rows:
            row = rows[-1]
            e = row.get("E_var") or row.get("energy") or row.get("e_var")
            if e:
                best.setdefault("source_csv", str(cp))
                best["E_var"] = float(e)
                dim = row.get("selected_dim") or row.get("dim")
                if dim:
                    best["selected_dim"] = int(float(dim))
                if row.get("gap_mHa"):
                    best["gap_mHa"] = float(row["gap_mHa"])
    if best and "gap_mHa" not in best:
        best["gap_mHa"] = gap_mha(best["E_var"])
    return best

def infer_dim_from_name(path: Path) -> Optional[int]:
    text = path.name
    patterns = [r"to(\d{4,6})", r"_(\d{4,6})\b", r"(\d{4,6})"]
    for pat in patterns:
        ms = re.findall(pat, text)
        if ms:
            return int(ms[-1])
    return None

def is_bad_path(path: Path) -> bool:
    s = str(path)
    return any(marker in s for marker in BAD_PATH_MARKERS)

def collect_checkpoints(root: Path):
    out = []
    for p in root.rglob("*"):
        if not p.is_dir():
            continue
        if not (p / "selected_dets_final.npy").exists():
            continue
        if not (p / "selected_coeff_final.npy").exists():
            continue
        s = parse_summary(p)
        dim = s.get("selected_dim") or infer_dim_from_name(p)
        e = s.get("E_var")
        gap = s.get("gap_mHa")
        if gap is None and e is not None:
            gap = gap_mha(e)
        out.append({
            "path": p,
            "dim": int(dim) if dim is not None else None,
            "E_var": float(e) if e is not None else None,
            "gap_mHa": float(gap) if gap is not None else None,
            "bad_marker": is_bad_path(p),
        })
    return out

def find_best_checkpoint(root: Path, preferred_dim: int, min_start_dim: int, max_start_gap_mha: float) -> Path:
    allc = collect_checkpoints(root)
    acceptable = []
    for c in allc:
        dim = c["dim"]
        gap = c["gap_mHa"]
        if c["bad_marker"]:
            continue
        if dim is None or dim < min_start_dim:
            continue
        if gap is not None and gap > max_start_gap_mha:
            continue
        score = (abs(dim - preferred_dim), -dim, gap if gap is not None else 9999.0)
        acceptable.append((score, c))

    if acceptable:
        acceptable.sort(key=lambda x: x[0])
        return acceptable[0][1]["path"]

    print("\n[v22] No acceptable auto-detected start checkpoint found.")
    print(f"[v22] Requirements: dim >= {min_start_dim}, gap <= {max_start_gap_mha} mHa, not a known bad branch.")
    print("\n[v22] Candidate checkpoints discovered:")
    for c in sorted(allc, key=lambda x: (x["dim"] or -1, str(x["path"]))):
        print(f"  dim={c['dim']} gap={c['gap_mHa']} bad_marker={c['bad_marker']} path={c['path']}")
    print("\n[v22] Set START_DIR to the real v21.3 20k checkpoint, for example:")
    print('  START_DIR="/full/path/to/v21.3/step_to20000" ./scripts/RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5_V2.sh')
    raise FileNotFoundError("No acceptable start checkpoint")

def find_restart_files(chk: Path, fallback_dim: int, fallback_gap: Optional[float]) -> Tuple[Path, Path, float, int, float]:
    dets = chk / "selected_dets_final.npy"
    coeff = chk / "selected_coeff_final.npy"
    if not dets.exists():
        raise FileNotFoundError(f"Missing {dets}")
    if not coeff.exists():
        raise FileNotFoundError(f"Missing {coeff}")
    s = parse_summary(chk)
    dim = int(s.get("selected_dim") or infer_dim_from_name(chk) or fallback_dim)
    if "E_var" in s:
        e = float(s["E_var"])
    elif fallback_gap is not None:
        e = E_REF + float(fallback_gap) / 1000.0
    else:
        raise RuntimeError(f"Could not determine E_var for checkpoint {chk}; pass --start-gap-mha")
    gap = float(s.get("gap_mHa", gap_mha(e)))
    return dets, coeff, e, dim, gap

def engine_help(engine: Path) -> str:
    try:
        r = subprocess.run([sys.executable, str(engine), "--help"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=20)
        return r.stdout
    except Exception:
        return ""

def make_command(args, engine: Path, dets: Path, coeff: Path, e: float, next_dim: int, outdir: Path, phase: str) -> list[str]:
    help_text = engine_help(engine)
    cmd = [
        sys.executable, str(engine),
        "--restart-dets", str(dets),
        "--restart-coeff", str(coeff),
        "--restart-energy", f"{e:.16f}",
        "--skip-initial-solve",
        "--initial-rank", str(args.initial_rank),
        "--selector-mode", args.selector_mode,
        "--max-excitation-rank", str(args.max_rank),
        "--max-global-select-rank", str(args.max_global_select_rank),
        "--allow-all-generated-ranks",
        "--min-select-rank", str(args.min_select_rank),
        "--max-rank-fraction", str(args.max_rank_fraction),
        "--max-selected-dim", str(next_dim),
        "--coeff-cutoff", str(args.coeff_cutoff),
        "--max-important-selected", str(args.max_important_selected),
        "--output-dir", str(outdir),
    ]
    optional = [
        ("--proposal-mode", args.proposal_mode),
        ("--en2-score-mode", args.en2_score_mode),
        ("--pauli-candidate-limit", args.pauli_candidate_limit),
        ("--candidate-pool-size", args.candidate_pool_size),
        ("--parent-topk", args.parent_topk),
        ("--diagnostic-every", args.diagnostic_every),
        ("--active-rotation", args.rotation),
        ("--rotation", args.rotation),
    ]
    for flag, value in optional:
        if value not in (None, "") and flag in help_text:
            cmd.extend([flag, str(value)])
    return cmd

def validate_summary(s: dict, previous_e: float, previous_gap: float):
    if not s or "E_var" not in s:
        raise RuntimeError("Could not parse E_var from output")
    e = float(s["E_var"])
    g = float(s.get("gap_mHa", gap_mha(e)))
    if e > previous_e + 1e-10:
        raise RuntimeError(f"Non-monotone E_var: previous {previous_e:.16f}, new {e:.16f}")
    if g > previous_gap + 1e-6:
        raise RuntimeError(f"Gap worsened: previous {previous_gap:.12f}, new {g:.12f}")
    if "N" in s and abs(float(s["N"]) - 12.0) > 1e-5:
        raise RuntimeError(f"N check failed: {s['N']}")
    if "Sz" in s and abs(float(s["Sz"])) > 1e-5:
        raise RuntimeError(f"Sz check failed: {s['Sz']}")

def append_run_log(log_path: Path, row: dict):
    exists = log_path.exists()
    fields = ["step","phase","dim","E_var","gap_mHa","gain_mHa","gain_per_kdet","outdir","timestamp"]
    with log_path.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        if not exists:
            w.writeheader()
        w.writerow({k: row.get(k, "") for k in fields})

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--engine", required=True)
    ap.add_argument("--start-dir", default="")
    ap.add_argument("--start-dim", type=int, default=20000)
    ap.add_argument("--min-start-dim", type=int, default=19500)
    ap.add_argument("--max-start-gap-mha", type=float, default=3.0)
    ap.add_argument("--start-gap-mha", type=float, default=None)
    ap.add_argument("--target-gap-mha", type=float, default=0.5)
    ap.add_argument("--max-dim", type=int, default=30000)
    ap.add_argument("--walltime-seconds", type=int, default=30000)
    ap.add_argument("--add-per-step", type=int, default=500)
    ap.add_argument("--output-root", default="cr2_v22_aggressive_from20k")
    ap.add_argument("--rotation", default="")
    ap.add_argument("--run", action="store_true")
    ap.add_argument("--initial-rank", type=int, default=10)
    ap.add_argument("--selector-mode", default="en2_topk")
    ap.add_argument("--proposal-mode", default="hybrid")
    ap.add_argument("--en2-score-mode", default="clipped_abs")
    ap.add_argument("--max-rank", type=int, default=10)
    ap.add_argument("--max-global-select-rank", type=int, default=10)
    ap.add_argument("--min-select-rank", type=int, default=3)
    ap.add_argument("--max-rank-fraction", type=float, default=0.45)
    ap.add_argument("--coeff-cutoff", default="1e-10")
    ap.add_argument("--max-important-selected", type=int, default=7000)
    ap.add_argument("--pauli-candidate-limit", type=int, default=8500)
    ap.add_argument("--candidate-pool-size", type=int, default=1500000)
    ap.add_argument("--parent-topk", type=int, default=7000)
    ap.add_argument("--diagnostic-every", type=int, default=3)
    ap.add_argument("--plateau-gain-per-kdet", type=float, default=0.05)
    ap.add_argument("--unlock-add-per-step", type=int, default=250)
    ap.add_argument("--unlock-max-rank", type=int, default=12)
    args = ap.parse_args()

    root = Path(args.root).expanduser().resolve()
    engine = Path(args.engine).expanduser().resolve()
    if not engine.is_file():
        raise SystemExit(f"Missing engine: {engine}")

    if args.start_dir:
        chk = Path(args.start_dir).expanduser().resolve()
        if not chk.is_dir():
            raise SystemExit(f"Missing START_DIR checkpoint: {chk}")
    else:
        chk = find_best_checkpoint(root, args.start_dim, args.min_start_dim, args.max_start_gap_mha)

    dets, coeff, e, dim, gap = find_restart_files(chk, args.start_dim, args.start_gap_mha)

    if dim < args.min_start_dim or gap > args.max_start_gap_mha:
        raise SystemExit(f"Refusing start checkpoint dim={dim}, gap={gap:.6f} mHa. Use correct v21.3 20k START_DIR.")

    run_root = Path(args.output_root).expanduser().resolve()
    run_root.mkdir(parents=True, exist_ok=True)
    log_path = run_root / "v22_progress.csv"

    print("[v22-v2] aggressive Cr2 CAS(12,12) production restart")
    print(f"[v22-v2] start_dir  = {chk}")
    print(f"[v22-v2] start_dim  = {dim}")
    print(f"[v22-v2] start_E    = {e:.16f}")
    print(f"[v22-v2] start_gap  = {gap:.12f} mHa")
    print(f"[v22-v2] target_gap = {args.target_gap_mha:.6f} mHa")
    print(f"[v22-v2] output     = {run_root}")

    step = 0
    recent = []
    start_time = time.time()

    while gap > args.target_gap_mha and dim < args.max_dim:
        if time.time() - start_time > args.walltime_seconds:
            print("[v22-v2] walltime reached")
            break

        phase = "production"
        add = args.add_per_step
        old_max_rank, old_global = args.max_rank, args.max_global_select_rank
        if len(recent) >= 2 and all(x < args.plateau_gain_per_kdet for x in recent[-2:]):
            phase = "unlock"
            add = args.unlock_add_per_step
            args.max_rank = args.unlock_max_rank
            args.max_global_select_rank = args.unlock_max_rank
            print("[v22-v2] plateau trigger: switching to unlock probe")

        next_dim = min(dim + add, args.max_dim)
        outdir = run_root / f"step{step:03d}_{phase}_to{next_dim}"
        outdir.mkdir(parents=True, exist_ok=True)

        cmd = make_command(args, engine, dets, coeff, e, next_dim, outdir, phase)
        args.max_rank, args.max_global_select_rank = old_max_rank, old_global

        print("\n[command]")
        print(" ".join(q(x) for x in cmd))
        if not args.run:
            print("[dry-run] Not executing. Add --run or set RUN=1 in shell wrapper.")
            return 0

        rc = subprocess.call(cmd)
        if rc != 0:
            raise SystemExit(f"Engine failed with exit code {rc}")

        s = parse_summary(outdir)
        validate_summary(s, e, gap)
        new_e = float(s["E_var"])
        new_gap = float(s.get("gap_mHa", gap_mha(new_e)))
        new_dim = int(s.get("selected_dim", next_dim))
        gain = gap - new_gap
        gain_per_k = gain / max((new_dim - dim) / 1000.0, 1e-9)

        print(f"[v22-v2] step result: dim={new_dim} gap={new_gap:.12f} gain/kdet={gain_per_k:.6f}")

        append_run_log(log_path, {
            "step": step, "phase": phase, "dim": new_dim, "E_var": f"{new_e:.16f}",
            "gap_mHa": f"{new_gap:.12f}", "gain_mHa": f"{gain:.12f}",
            "gain_per_kdet": f"{gain_per_k:.12f}", "outdir": str(outdir),
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
        })

        nd = outdir / "selected_dets_final.npy"
        nc = outdir / "selected_coeff_final.npy"
        if not nd.exists() or not nc.exists():
            raise RuntimeError(f"Missing restart files in {outdir}")

        dets, coeff, e, gap, dim = nd, nc, new_e, new_gap, new_dim
        recent.append(gain_per_k)
        step += 1

    print("\n[v22-v2 done]")
    print(f"final_dim={dim}")
    print(f"final_E_var={e:.16f}")
    print(f"final_gap_mHa={gap:.12f}")
    print(f"progress_csv={log_path}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
