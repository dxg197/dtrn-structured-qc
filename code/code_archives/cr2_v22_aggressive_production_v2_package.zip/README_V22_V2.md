# Cr2 v22 aggressive production v2

This version fixes the autodetection bug that selected the corrupted `restart_v214b_v1425compat.../step001_to15926` checkpoint.

It now refuses auto-start checkpoints unless:

- dimension >= `MIN_START_DIM` (default 19500)
- gap <= `MAX_START_GAP_MHA` (default 3.0 mHa)
- path is not a known bad compatibility branch

Install from package root:

```bash
unzip cr2_v22_aggressive_production_v2_package.zip
cp cr2_v22_aggressive_driver_v2.py .
cp RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5_V2.sh scripts/
chmod +x cr2_v22_aggressive_driver_v2.py scripts/RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5_V2.sh
```

Dry-run:

```bash
./scripts/RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5_V2.sh
```

If no 20k checkpoint is found, point directly at it:

```bash
START_DIR="/full/path/to/v21.3/20k/checkpoint" \
./scripts/RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5_V2.sh
```

Real run:

```bash
START_DIR="/full/path/to/v21.3/20k/checkpoint" RUN=1 \
./scripts/RUN_CR2_V22_AGGRESSIVE_FROM_20K_TO_0P5_V2.sh
```
