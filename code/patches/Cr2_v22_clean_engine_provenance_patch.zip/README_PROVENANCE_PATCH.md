# Clean-v22 provenance/permutation validation patch

The active-rotation rebuild reduced the imported 20k gap only from ~2809.5 mHa to ~2704.6 mHa. That is still nowhere near the expected ~1.102 mHa, so active rotation alone is not sufficient.

This patch adds:

1. `RUN_CLEAN_V22_VALIDATE_PERMUTATIONS.sh`  
   Tests common active-orbital permutations while importing legacy interleaved bitstrings.

2. `FIND_LEGACY_INTEGRAL_PROVENANCE.sh`  
   Searches for exact old integral/Hamiltonian/cache provenance that can be imported into the clean engine.

## Install

From `Cr2_v22_clean_engine_standalone`:

```bash
unzip Cr2_v22_clean_engine_provenance_patch.zip
chmod +x RUN_CLEAN_V22_VALIDATE_PERMUTATIONS.sh
chmod +x FIND_LEGACY_INTEGRAL_PROVENANCE.sh
```

## Test simple orbital permutations

```bash
INTEGRALS="$PWD/v22_clean_cache_no/active_integrals_cr2_cas12.npz" \
LEGACY_DIR="$PWD/v21_3_final_results/step028_restart_r10_to20000" \
./RUN_CLEAN_V22_VALIDATE_PERMUTATIONS.sh
```

If all gaps remain thousands of mHa, the mismatch is not a simple orbital permutation.

## Search for exact legacy provenance

```bash
ROOT="$PWD" ./FIND_LEGACY_INTEGRAL_PROVENANCE.sh
```

and then search the old package:

```bash
ROOT="/path/to/Cr2_v21.4b_dtrn_active_rank_package" ./FIND_LEGACY_INTEGRAL_PROVENANCE.sh
```

The ideal artifact is an old `.npz` or `.pkl` containing active-space `h1e`, `eri`, `ecore`, or enough Hamiltonian metadata to reconstruct them exactly.
