#!/usr/bin/env bash
set -euo pipefail

ROOT="${ROOT:-.}"

echo "Searching for likely legacy Hamiltonian/integral/cache/provenance files under:"
echo "  $ROOT"
echo

echo "== Files with cache/integral/hamiltonian/rotation/provenance names =="
find "$ROOT" -type f | grep -Ei 'pyscf|hamiltonian|integral|eri|h1e|ecore|cache|pkl|pickle|npz|active_rotation|rotation|provenance|metadata|29717|29709|c657|edb662' || true

echo
echo "== Text hits for 29717 / active_rotation / c657 / edb662 =="
grep -R "29717\|29709\|active_rotation\|c65788197e7dc63e\|edb66241efaa1fca\|E_CASSCF/ref\|from_preset" -n "$ROOT" 2>/dev/null || true

echo
echo "If you find an old integral/cache file that stores h1e/eri/ecore or a pkl with the exact active-space Hamiltonian, paste its path."
