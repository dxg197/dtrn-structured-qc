from __future__ import annotations

import argparse
from pathlib import Path
import json
import re
import numpy as np

from .integrals import load_integrals
from .sector import make_sector
from .utils import gap_mha

def last_number(p: Path) -> int:
    nums = [int(x) for x in re.findall(r"\d+", p.name)]
    return nums[-1] if nums else -1

def find_legacy_files(path: Path):
    dets = sorted(path.glob("selected_dets_final*.npy")) or sorted(path.glob("selected_dets_iter*_dim*.npy"))
    coeff = sorted(path.glob("selected_coeff_final*.npy")) or sorted(path.glob("selected_coeff_iter*_dim*.npy"))
    if not dets or not coeff:
        raise FileNotFoundError(f"Could not find legacy selected_dets/selected_coeff in {path}")
    return sorted(dets, key=last_number)[-1], sorted(coeff, key=last_number)[-1]

def coeff_variants(craw):
    if np.iscomplexobj(craw):
        idx = int(np.argmax(np.abs(craw)))
        phase = np.exp(-1j * np.angle(craw[idx])) if abs(craw[idx]) > 0 else 1.0
        variants = [
            ("phase_aligned_real", np.real(craw * phase)),
            ("real", np.real(craw)),
            ("imag", np.imag(craw)),
        ]
    else:
        variants = [("real", np.asarray(craw, dtype=np.float64))]
    out = []
    for name, c in variants:
        c = np.asarray(c, dtype=np.float64)
        n = np.linalg.norm(c)
        if n > 0:
            out.append((name, c / n))
    return out

def parse_perm(s: str, ncas: int):
    vals = [int(x) for x in re.split(r"[,\s]+", s.strip()) if x != ""]
    if sorted(vals) != list(range(ncas)):
        raise ValueError(f"Invalid permutation {vals}; expected 0..{ncas-1}")
    return tuple(vals)

def candidate_perms(ncas: int):
    base = tuple(range(ncas))
    blocks = [[0,1], [2,3,4], [5,6,7], [8,9], [10,11]]
    raw = [
        ("identity", base),
        ("reverse", tuple(reversed(base))),
        ("middle_blocks_swapped", tuple([0,1,5,6,7,2,3,4,8,9,10,11])),
        ("outer_to_inner", tuple([0,1,10,11,2,3,4,8,9,5,6,7])),
        ("inner_to_outer", tuple([5,6,7,2,3,4,8,9,0,1,10,11])),
        ("shift_left_blocks", tuple([2,3,4,0,1,5,6,7,8,9,10,11])),
        ("coarse_middle", tuple([0,1,2,3,4,8,9,5,6,7,10,11])),
        ("reverse_within_blocks", tuple([x for b in blocks for x in reversed(b)])),
        ("reverse_block_order", tuple([x for b in reversed(blocks) for x in b])),
        ("reverse_blocks_and_within", tuple([x for b in reversed(blocks) for x in reversed(b)])),
    ]
    seen = set()
    out = []
    for name, p in raw:
        if len(p) == ncas and sorted(p) == list(range(ncas)) and p not in seen:
            out.append((name, p))
            seen.add(p)
    return out

def convert_interleaved_with_perm(dets, sector, perm):
    out = []
    bad = 0
    for d0 in np.asarray(dets, dtype=np.uint64).reshape(-1):
        d = int(d0)
        a = 0
        b = 0
        for old_i, new_i in enumerate(perm):
            if d & (1 << (2 * old_i)):
                a |= 1 << new_i
            if d & (1 << (2 * old_i + 1)):
                b |= 1 << new_i
        ia = sector.alpha_addr.get(a)
        ib = sector.beta_addr.get(b)
        if ia is None or ib is None:
            bad += 1
            out.append(-1)
        else:
            out.append(sector.flat(ia, ib))
    if bad:
        raise ValueError(f"{bad}/{len(dets)} determinants not in sector")
    return np.asarray(out, dtype=np.int64)

def rayleigh(h1e, eri, ecore, ncas, nelecas, sector, flat, coeff):
    from pyscf.fci import direct_spin1
    h2e = direct_spin1.absorb_h1e(h1e, eri, ncas, nelecas, 0.5)
    full = np.zeros((sector.na, sector.nb), dtype=np.float64)
    ia, ib = sector.unflat(flat)
    full[ia, ib] = coeff
    sigma = direct_spin1.contract_2e(h2e, full, ncas, nelecas) + ecore * full
    return float(np.dot(coeff, sigma[ia, ib]))

def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--integrals", required=True)
    ap.add_argument("--legacy-dir", required=True)
    ap.add_argument("--permutation", action="append", default=[])
    ap.add_argument("--output-json", default="permutation_validation.json")
    ap.add_argument("--accept-gap-mha", type=float, default=5.0)
    args = ap.parse_args(argv)

    h1e, eri, ecore, e_ref, ncas, nelecas = load_integrals(args.integrals)
    sector = make_sector(ncas, nelecas)
    det_file, coeff_file = find_legacy_files(Path(args.legacy_dir))
    dets = np.load(det_file)
    coeff_raw = np.load(coeff_file)

    print(f"[perm-validate] integrals={args.integrals}")
    print(f"[perm-validate] E_ref={e_ref:.16f}")
    print(f"[perm-validate] dets={det_file}")
    print(f"[perm-validate] coeff={coeff_file}")

    perms = candidate_perms(ncas)
    for i, pstr in enumerate(args.permutation):
        perms.append((f"user_{i}", parse_perm(pstr, ncas)))

    seen = set()
    unique = []
    for name, p in perms:
        if p not in seen:
            unique.append((name, p))
            seen.add(p)

    results = []
    for pname, perm in unique:
        try:
            flat = convert_interleaved_with_perm(dets, sector, perm)
        except Exception as exc:
            print(f"[perm-validate] perm={pname} failed: {exc}")
            continue
        for cname, coeff in coeff_variants(coeff_raw):
            e = rayleigh(h1e, eri, ecore, ncas, nelecas, sector, flat, coeff)
            gap = gap_mha(e, e_ref)
            row = {"gap_mHa": gap, "E_var": e, "perm_name": pname, "perm": list(perm), "coeff": cname}
            results.append(row)
            print(f"[perm-validate] perm={pname:24s} coeff={cname:18s} E={e:.16f} gap={gap:.6f}")

    if not results:
        raise SystemExit("No valid candidates")
    results.sort(key=lambda r: r["gap_mHa"])
    best = results[0]
    print()
    print("[perm-validate] BEST")
    print(json.dumps(best, indent=2))
    Path(args.output_json).write_text(json.dumps({"results": results, "best": best}, indent=2) + "\n")
    if best["gap_mHa"] > args.accept_gap_mha:
        raise SystemExit(
            f"FAIL: best permutation gap {best['gap_mHa']:.6f} mHa exceeds {args.accept_gap_mha}. "
            "This is not a simple active-orbital permutation; recover exact legacy integral/cache provenance or run clean-v22 from zero."
        )
    print("[perm-validate] PASS: a compatible permutation was found.")

if __name__ == "__main__":
    main()
