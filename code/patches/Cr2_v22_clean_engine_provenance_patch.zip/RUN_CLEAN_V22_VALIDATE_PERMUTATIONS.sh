#!/usr/bin/env bash
set -euo pipefail

INTEGRALS="${INTEGRALS:-v22_clean_cache_no/active_integrals_cr2_cas12.npz}"
LEGACY_DIR="${LEGACY_DIR:-}"

if [ -z "$LEGACY_DIR" ]; then
  echo "Set LEGACY_DIR to the v21.3 20k checkpoint directory."
  exit 1
fi

python3 -m cr2v22.validate_restart_permutations \
  --integrals "$INTEGRALS" \
  --legacy-dir "$LEGACY_DIR" \
  --output-json "${OUTPUT_JSON:-permutation_validation.json}" \
  --accept-gap-mha "${ACCEPT_GAP_MHA:-5.0}"
