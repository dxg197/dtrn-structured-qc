#!/usr/bin/env bash
set -euo pipefail

# Rebuild clean-v22 integrals in a fresh cache directory using the v21.3/v14.35
# active rotation. This avoids accidentally reusing canonical CASSCF integrals.

ROTATION="${ROTATION:-}"
CACHE_DIR="${CACHE_DIR:-v22_clean_cache_no_rotation_fixed}"

if [ -z "$ROTATION" ]; then
  echo "Set ROTATION to the active_rotation_from_restart.npy path from the legacy package."
  echo
  echo "Example:"
  echo 'ROTATION="/Users/.../Cr2_v21.4b_dtrn_active_rank_package/cr2_v1435_no_results/01_make_no/active_rotation_from_restart.npy" ./REBUILD_INTEGRALS_WITH_ACTIVE_ROTATION.sh'
  exit 1
fi

if [ ! -f "$ROTATION" ]; then
  echo "Missing ROTATION file: $ROTATION"
  exit 1
fi

echo "Building clean-v22 integrals with active rotation:"
echo "  ROTATION=$ROTATION"
echo "  CACHE_DIR=$CACHE_DIR"

python3 -m cr2v22.cli build-integrals \
  --output-dir "$CACHE_DIR" \
  --bond 1.6788 \
  --basis cc-pvdz \
  --ncas 12 \
  --nelecas 12 \
  --active-rotation "$ROTATION" \
  --force

echo
echo "Metadata:"
cat "$CACHE_DIR/active_integrals_cr2_cas12.meta.json"
