# Clean v22 import validation patch

Your clean-v22 run imported the legacy 20k checkpoint but started at a huge gap:

```text
start_dim=20000
E=-2083.841295905409
gap=2809.537410 mHa
```

That means the imported legacy vector is not compatible with the active-space integrals currently in `v22_clean_cache`.

The most likely cause is that the clean standalone folder built **canonical CASSCF integrals without the v14.35/v21.3 active rotation**. The original legacy determinant vector is in that natural-orbital basis, so it must be validated against matching active integrals.

## Install

From inside `Cr2_v22_clean_engine_standalone`:

```bash
unzip Cr2_v22_clean_engine_patch_validate_import.zip
chmod +x RUN_CLEAN_V22_VALIDATE_LEGACY_20K.sh
chmod +x REBUILD_INTEGRALS_WITH_ACTIVE_ROTATION.sh
```

## Validate current cache

```bash
LEGACY_DIR="$PWD/v21_3_final_results/step028_restart_r10_to20000" \
./RUN_CLEAN_V22_VALIDATE_LEGACY_20K.sh
```

If the best gap is not near 1.102 mHa, do not continue.

## Rebuild integrals with active rotation

Point `ROTATION` at the active rotation from your legacy package, for example:

```bash
ROTATION="/Users/garrison/Documents/Old Documents - David Garrison’s MacBook Air/Virtual Flash Drive/Quantum Neural Networks/Quantum Chemistry Problems /dtrn_qc_mac/Cr2_v21.4b_dtrn_active_rank_package/cr2_v1435_no_results/01_make_no/active_rotation_from_restart.npy" \
CACHE_DIR="v22_clean_cache_no" \
./REBUILD_INTEGRALS_WITH_ACTIVE_ROTATION.sh
```

Then validate the new cache:

```bash
INTEGRALS="$PWD/v22_clean_cache_no/active_integrals_cr2_cas12.npz" \
LEGACY_DIR="$PWD/v21_3_final_results/step028_restart_r10_to20000" \
./RUN_CLEAN_V22_VALIDATE_LEGACY_20K.sh
```

Only after this validation gives a gap near 1.102 mHa should you run:

```bash
INTEGRALS="$PWD/v22_clean_cache_no/active_integrals_cr2_cas12.npz" \
LEGACY_DIR="$PWD/v21_3_final_results/step028_restart_r10_to20000" \
RUN=1 ./RUN_CLEAN_V22_FROM_LEGACY_20K_TO_0P5.sh
```
