#!/usr/bin/env bash
set -euo pipefail

CACHE_DIR="${CACHE_DIR:-v22_clean_cache}"
INTEGRALS="${INTEGRALS:-$CACHE_DIR/active_integrals_cr2_cas12.npz}"
LEGACY_DIR="${LEGACY_DIR:-}"

if [ -z "$LEGACY_DIR" ]; then
  echo "Set LEGACY_DIR to the v21.3 20k checkpoint directory."
  echo 'Example: LEGACY_DIR="$PWD/v21_3_final_results/step028_restart_r10_to20000" ./RUN_CLEAN_V22_VALIDATE_LEGACY_20K.sh'
  exit 1
fi

python3 -m cr2v22.validate_restart \
  --integrals "$INTEGRALS" \
  --legacy-dir "$LEGACY_DIR" \
  --accept-gap-mha "${ACCEPT_GAP_MHA:-5.0}"
