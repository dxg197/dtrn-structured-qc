from __future__ import annotations

import argparse
from pathlib import Path
import re
import numpy as np

from .integrals import load_integrals
from .sector import make_sector, legacy_spin_orbital_to_flat
from .utils import gap_mha

def last_number(p: Path) -> int:
    nums = [int(x) for x in re.findall(r"\d+", p.name)]
    return nums[-1] if nums else -1

def find_legacy_files(path: Path):
    dets = sorted(path.glob("selected_dets_final*.npy")) or sorted(path.glob("selected_dets_iter*_dim*.npy"))
    coeff = sorted(path.glob("selected_coeff_final*.npy")) or sorted(path.glob("selected_coeff_iter*_dim*.npy"))
    if not dets or not coeff:
        raise FileNotFoundError(f"Could not find legacy selected_dets/selected_coeff in {path}")
    return sorted(dets, key=last_number)[-1], sorted(coeff, key=last_number)[-1]

def coeff_variants(craw):
    variants = []
    if np.iscomplexobj(craw):
        idx = int(np.argmax(np.abs(craw)))
        if abs(craw[idx]) > 0:
            phase = np.exp(-1j * np.angle(craw[idx]))
            aligned = craw * phase
        else:
            aligned = craw
        variants.append(("phase_aligned_real", np.real(aligned)))
        variants.append(("real", np.real(craw)))
        variants.append(("imag", np.imag(craw)))
    else:
        variants.append(("real", np.asarray(craw, dtype=np.float64)))
    out = []
    for name, c in variants:
        c = np.asarray(c, dtype=np.float64)
        n = np.linalg.norm(c)
        if n > 0:
            out.append((name, c / n))
    return out

def rayleigh(h1e, eri, ecore, ncas, nelecas, sector, flat, coeff):
    from pyscf.fci import direct_spin1
    h2e = direct_spin1.absorb_h1e(h1e, eri, ncas, nelecas, 0.5)
    full = np.zeros((sector.na, sector.nb), dtype=np.float64)
    ia, ib = sector.unflat(flat)
    full[ia, ib] = coeff
    sigma = direct_spin1.contract_2e(h2e, full, ncas, nelecas) + ecore * full
    return float(np.dot(coeff, sigma[ia, ib]))

def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--integrals", required=True)
    ap.add_argument("--legacy-dir", required=True)
    ap.add_argument("--accept-gap-mha", type=float, default=5.0)
    args = ap.parse_args(argv)

    h1e, eri, ecore, e_ref, ncas, nelecas = load_integrals(args.integrals)
    sector = make_sector(ncas, nelecas)
    det_file, coeff_file = find_legacy_files(Path(args.legacy_dir))
    dets = np.load(det_file)
    coeff_raw = np.load(coeff_file)

    print(f"[validate] integrals={args.integrals}")
    print(f"[validate] E_ref={e_ref:.16f}")
    print(f"[validate] legacy dets={det_file}")
    print(f"[validate] legacy coeff={coeff_file}")
    print(f"[validate] coeff dtype={coeff_raw.dtype} complex={np.iscomplexobj(coeff_raw)}")
    if np.iscomplexobj(coeff_raw):
        im_ratio = np.linalg.norm(np.imag(coeff_raw)) / max(np.linalg.norm(coeff_raw), 1e-300)
        print(f"[validate] coefficient imaginary norm ratio={im_ratio:.6e}")

    results = []
    for layout in ("interleaved", "block"):
        try:
            flat = legacy_spin_orbital_to_flat(dets, sector, layout=layout)
        except Exception as exc:
            print(f"[validate] layout={layout} failed: {exc}")
            continue
        for cname, coeff in coeff_variants(coeff_raw):
            e = rayleigh(h1e, eri, ecore, ncas, nelecas, sector, flat, coeff)
            gap = gap_mha(e, e_ref)
            results.append((gap, e, layout, cname))
            print(f"[validate] layout={layout:11s} coeff={cname:18s} E={e:.16f} gap={gap:.6f} mHa")

    if not results:
        raise SystemExit("No valid layout/coeff combination found")
    results.sort(key=lambda x: x[0])
    best_gap, best_e, best_layout, best_coeff = results[0]
    print()
    print(f"[validate] BEST layout={best_layout} coeff={best_coeff} E={best_e:.16f} gap={best_gap:.6f} mHa")
    if best_gap > args.accept_gap_mha:
        raise SystemExit(
            f"FAIL: best imported checkpoint gap {best_gap:.6f} mHa exceeds {args.accept_gap_mha}. "
            "This usually means the active integrals/orbital basis do not match the legacy checkpoint."
        )
    print("[validate] PASS: imported legacy checkpoint is compatible with these integrals.")

if __name__ == "__main__":
    main()
