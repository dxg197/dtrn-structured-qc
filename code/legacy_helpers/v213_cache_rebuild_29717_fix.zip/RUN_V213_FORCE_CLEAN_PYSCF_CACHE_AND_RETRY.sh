#!/usr/bin/env bash
set -euo pipefail

# More aggressive fallback: backs up all obvious PySCF cache directories/files
# under the package. Use only if disabling the edb662 cache still reloads 29709.

PACKAGE_ROOT="${PACKAGE_ROOT:-$PWD}"
cd "$PACKAGE_ROOT"

START_DIR="${START_DIR:-$PWD/results/cr2_12_12_v213_restart_15000_to20000_20260512_111531/step028_restart_r10_to20000}"
RUN_SCRIPT="${RUN_SCRIPT:-$PWD/RUN_V213_NATIVE_FROM_20K_TO_0P5_SAFE_V2.sh}"

BACKUP_DIR="$PACKAGE_ROOT/cache_backup_all_pyscf_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"

echo "PACKAGE_ROOT=$PACKAGE_ROOT"
echo "START_DIR=$START_DIR"
echo "RUN_SCRIPT=$RUN_SCRIPT"
echo "BACKUP_DIR=$BACKUP_DIR"
echo

find . \( -type d -name ".pyscf_cache" -o -type d -name "*pyscf_cache*" \) -print | while read -r d; do
  dest="$BACKUP_DIR/${d#./}"
  mkdir -p "$(dirname "$dest")"
  echo "Moving cache dir: $d -> $dest"
  mv "$d" "$dest"
done

find . -type f | grep -Ei 'edb66241efaa1fca|pyscf.*cache|hamiltonian.*cache|cache.*pkl|cache.*pickle' | while read -r f; do
  [ -e "$f" ] || continue
  dest="$BACKUP_DIR/${f#./}"
  mkdir -p "$(dirname "$dest")"
  echo "Moving cache file: $f -> $dest"
  mv "$f" "$dest"
done

echo
echo "Caches backed up. Running monitored restart only if EXECUTE_RETRY=1."
CMD=(env START_DIR="$START_DIR" RUN=1 "$RUN_SCRIPT")
printf 'Command: '
printf '%q ' "${CMD[@]}"
echo

if [ "${EXECUTE_RETRY:-0}" = "1" ]; then
  "${CMD[@]}"
else
  echo "Not executing automatically."
fi
