#!/usr/bin/env bash
set -euo pipefail

# This script backs up the known-bad 29709-term cache key seen in the failed
# restart:
#
#   edb66241efaa1fca -> 29709 terms
#
# It does not delete anything permanently. It moves matching cache files into a
# timestamped backup folder so the native v21.3 engine is forced to rebuild/load
# the correct 29717-term Hamiltonian path if the provenance is present.

PACKAGE_ROOT="${PACKAGE_ROOT:-$PWD}"
cd "$PACKAGE_ROOT"

START_DIR="${START_DIR:-$PWD/results/cr2_12_12_v213_restart_15000_to20000_20260512_111531/step028_restart_r10_to20000}"
RUN_SCRIPT="${RUN_SCRIPT:-$PWD/RUN_V213_NATIVE_FROM_20K_TO_0P5_SAFE_V2.sh}"
BAD_KEY="${BAD_KEY:-edb66241efaa1fca}"

echo "PACKAGE_ROOT=$PACKAGE_ROOT"
echo "START_DIR=$START_DIR"
echo "RUN_SCRIPT=$RUN_SCRIPT"
echo "BAD_KEY=$BAD_KEY"
echo

if [ ! -d "$START_DIR" ]; then
  echo "Missing START_DIR: $START_DIR"
  exit 1
fi

if [ ! -x "$RUN_SCRIPT" ]; then
  echo "Missing executable run script: $RUN_SCRIPT"
  echo "Install v213_native_restart_20k_to_0p5_safe_v2.zip first."
  exit 1
fi

# Ensure root-relative active rotation exists if an engine-local copy exists.
ROOT_ROT="cr2_v1435_no_results/01_make_no/active_rotation_from_restart.npy"
ENGINE_ROT="engines/cas12/cr2_v1435_no_results/01_make_no/active_rotation_from_restart.npy"

if [ ! -e "$ROOT_ROT" ] && [ -e "$ENGINE_ROT" ]; then
  echo "Creating root-relative active-rotation symlink:"
  echo "  $ROOT_ROT -> ../../engines/cas12/cr2_v1435_no_results/01_make_no/active_rotation_from_restart.npy"
  mkdir -p "$(dirname "$ROOT_ROT")"
  ln -s "../../engines/cas12/cr2_v1435_no_results/01_make_no/active_rotation_from_restart.npy" "$ROOT_ROT"
fi

echo "Active rotation check:"
if [ -e "$ROOT_ROT" ]; then
  ls -lah "$ROOT_ROT"
else
  echo "WARNING: root-relative active rotation is missing: $ROOT_ROT"
fi
echo

BACKUP_DIR="$PACKAGE_ROOT/cache_backup_bad_29709_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"

echo "Searching for bad cache files..."
mapfile -t BAD_FILES < <(find . -type f -name "*${BAD_KEY}*" -print)

if [ "${#BAD_FILES[@]}" -eq 0 ]; then
  echo "No files matching *${BAD_KEY}* found."
else
  printf '%s\n' "${BAD_FILES[@]}" | while read -r f; do
    dest="$BACKUP_DIR/${f#./}"
    mkdir -p "$(dirname "$dest")"
    echo "Backing up bad cache: $f -> $dest"
    mv "$f" "$dest"
  done
fi

echo
echo "Backed-up cache files are in:"
echo "  $BACKUP_DIR"
echo

echo "Now run a monitored restart. It should rebuild or load 29717 terms."
echo "If it prints 29709 again, the wrapper will kill it."
echo

CMD=(env START_DIR="$START_DIR" RUN=1 "$RUN_SCRIPT")
printf 'Command: '
printf '%q ' "${CMD[@]}"
echo

if [ "${EXECUTE_RETRY:-0}" = "1" ]; then
  "${CMD[@]}"
else
  echo "Not executing automatically. To execute now:"
  echo
  echo "EXECUTE_RETRY=1 START_DIR=\"$START_DIR\" ./RUN_V213_DISABLE_29709_CACHE_AND_RETRY.sh"
fi
