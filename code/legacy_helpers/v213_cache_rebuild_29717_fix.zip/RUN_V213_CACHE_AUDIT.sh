#!/usr/bin/env bash
set -euo pipefail

PACKAGE_ROOT="${PACKAGE_ROOT:-$PWD}"
cd "$PACKAGE_ROOT"

echo "PACKAGE_ROOT=$PACKAGE_ROOT"
echo

echo "== Active rotation locations =="
for p in \
  "cr2_v1435_no_results/01_make_no/active_rotation_from_restart.npy" \
  "engines/cas12/cr2_v1435_no_results/01_make_no/active_rotation_from_restart.npy" \
  "v21_3_final_results/cr2_v1435_no_results/01_make_no/active_rotation_from_restart.npy"
do
  if [ -e "$p" ]; then
    ls -lah "$p"
  else
    echo "missing: $p"
  fi
done

echo
echo "== PySCF/cache-like files =="
find . -type f | grep -Ei 'pyscf|cache|hamiltonian|29717|29709|edb662|c657|active_rotation|pkl|pickle|npz' || true

echo
echo "== Bad cache files matching edb66241efaa1fca =="
find . -type f -name "*edb66241efaa1fca*" -print -exec ls -lah {} \; || true

echo
echo "== Text hits in logs/json/source =="
grep -R "29717\|29709\|edb66241efaa1fca\|active_rotation:c65788197e7dc63e\|active_rotation\|cache hit\|cache miss\|from_preset" -n . 2>/dev/null | head -200 || true

echo
echo "== 20k checkpoint summaries =="
find . -type f | grep -Ei 'step028_restart_r10_to20000.*json|cr2_v1425_final_step028_restart_r10_to20000.json' | while read -r f; do
  echo "--- $f"
  python3 - "$f" <<'PY'
import json, sys
p=sys.argv[1]
try:
    d=json.load(open(p))
except Exception as e:
    print("could not read json:", e)
    raise SystemExit
print("final_selected_dim:", d.get("final_selected_dim", d.get("selected_dim")))
print("E_var:", d.get("E_var"))
print("gap_vs_CASSCF_mHa:", d.get("gap_vs_CASSCF_mHa"))
print("n_terms:", d.get("n_terms"))
print("metadata.active_rotation_tag:", (d.get("metadata") or {}).get("active_rotation_tag"))
PY
done
