# v21.3 29717 cache rebuild fix

The v21.3 native restart wrapper is working correctly: it found the valid 20k checkpoint, but killed the run as soon as the engine loaded the wrong Hamiltonian cache:

```text
cache hit (edb66241efaa1fca) -> 29709 terms
```

The start checkpoint metadata is good:

```text
START_DIM=20000
START_E=-2086.6497310382792421
START_GAP_MHA=1.102265785448
TERMS=29717
ACTIVE_TAG=active_rotation:c65788197e7dc63e
```

So the next fix is to prevent the engine from using the stale/bad `edb66241efaa1fca` 29709-term cache.

## Install

Inside `Cr2_v21.3_failfast_sub24h_package`:

```bash
unzip v213_cache_rebuild_29717_fix.zip
chmod +x RUN_V213_CACHE_AUDIT.sh
chmod +x RUN_V213_DISABLE_29709_CACHE_AND_RETRY.sh
chmod +x RUN_V213_FORCE_CLEAN_PYSCF_CACHE_AND_RETRY.sh
```

## Audit

```bash
./RUN_V213_CACHE_AUDIT.sh
```

## Preferred fix: back up only the known-bad cache key

```bash
START_DIR="$PWD/results/cr2_12_12_v213_restart_15000_to20000_20260512_111531/step028_restart_r10_to20000" \
./RUN_V213_DISABLE_29709_CACHE_AND_RETRY.sh
```

Then execute:

```bash
START_DIR="$PWD/results/cr2_12_12_v213_restart_15000_to20000_20260512_111531/step028_restart_r10_to20000" \
EXECUTE_RETRY=1 ./RUN_V213_DISABLE_29709_CACHE_AND_RETRY.sh
```

The native restart wrapper will still kill the run if it sees `29709 terms` again.

## More aggressive fallback

If the engine still reloads 29709 from another cache location:

```bash
START_DIR="$PWD/results/cr2_12_12_v213_restart_15000_to20000_20260512_111531/step028_restart_r10_to20000" \
EXECUTE_RETRY=1 ./RUN_V213_FORCE_CLEAN_PYSCF_CACHE_AND_RETRY.sh
```

This backs up all obvious PySCF cache directories/files under the package.

## Expected outcome

A good engine load should print:

```text
29717 terms
```

If it still prints:

```text
29709 terms
```

the correct v21.3 29717 cache/provenance is missing from this local package, and the 20k checkpoint cannot be safely continued here until that provenance is restored.
