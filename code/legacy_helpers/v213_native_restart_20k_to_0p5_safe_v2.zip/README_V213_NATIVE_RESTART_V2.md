# Native v21.3 restart script v2

This fixes the `PermissionError` caused by stale absolute paths in the old JSON `restart_rows`.

The v21.3 final JSON may point to paths like:

```text
/Users/garrison/Documents/...
```

while the current machine/package path is:

```text
/Users/dgarrison/Library/Mobile Documents/...
```

v2 now prefers the local `selected_dets_final*.npy` and `selected_coeff_final*.npy` files inside `START_DIR`, and only tries JSON paths afterward with PermissionError-safe checks.

## Install

From inside `Cr2_v21.3_failfast_sub24h_package`:

```bash
unzip v213_native_restart_20k_to_0p5_safe_v2.zip
chmod +x RUN_V213_NATIVE_FROM_20K_TO_0P5_SAFE_V2.sh
chmod +x v213_native_restart_safe_v2.py
```

## Dry run

```bash
START_DIR="$PWD/results/cr2_12_12_v213_restart_15000_to20000_20260512_111531/step028_restart_r10_to20000" \
./RUN_V213_NATIVE_FROM_20K_TO_0P5_SAFE_V2.sh
```

## Real run

```bash
START_DIR="$PWD/results/cr2_12_12_v213_restart_15000_to20000_20260512_111531/step028_restart_r10_to20000" \
RUN=1 ./RUN_V213_NATIVE_FROM_20K_TO_0P5_SAFE_V2.sh
```

The script still refuses to continue if it sees `29709 terms` or if the output is non-monotone.
