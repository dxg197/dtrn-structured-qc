#!/usr/bin/env python3
"""
Native v21.3 restart controller for Cr2 CAS(12,12), v2.

v2 fix:
  - Prefer local restart files inside START_DIR.
  - Ignore stale/inaccessible absolute paths stored in legacy JSON restart_rows.
  - Catch PermissionError/OSError while probing old /Users/garrison paths.

Run inside the original Cr2_v21.3_failfast_sub24h_package.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time
from typing import Any

EXPECTED_TERMS = 29717
BAD_TERMS = 29709
EXPECTED_ACTIVE_TAG = "active_rotation:c65788197e7dc63e"
E_REF = -2086.650833304065

def q(x: Any) -> str:
    return shlex.quote(str(x))

def gap_mha(e: float, ref: float = E_REF) -> float:
    return (float(e) - float(ref)) * 1000.0

def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)

def exists_safe(path: Path) -> bool:
    try:
        return path.exists()
    except (OSError, PermissionError):
        return False

def last_number(p: Path) -> int:
    nums = [int(x) for x in re.findall(r"\d+", p.name)]
    return nums[-1] if nums else -1

def find_json_summary(d: Path) -> Path:
    cands = sorted(d.glob("*final*.json")) + sorted(d.glob("cr2_v1425_final*.json")) + sorted(d.glob("*.json"))
    scored = []
    for p in cands:
        try:
            j = read_json(p)
        except Exception:
            continue
        if "E_var" in j or "final_selected_dim" in j:
            scored.append(p)
    if not scored:
        raise FileNotFoundError(f"No final JSON summary found in {d}")
    return sorted(scored, key=last_number)[-1]

def find_restart_pair(d: Path, summary: dict[str, Any] | None = None) -> tuple[Path, Path]:
    """
    Prefer files physically inside d. Legacy JSON restart_rows may contain stale
    absolute paths from another Mac username or iCloud mount and must not block fallback.
    """
    det_cands = sorted(d.glob("selected_dets_final*.npy"), key=last_number)
    coeff_cands = sorted(d.glob("selected_coeff_final*.npy"), key=last_number)
    if det_cands and coeff_cands:
        return det_cands[-1], coeff_cands[-1]

    det_cands = sorted(d.glob("selected_dets_iter*_dim*.npy"), key=last_number)
    coeff_cands = sorted(d.glob("selected_coeff_iter*_dim*.npy"), key=last_number)
    if det_cands and coeff_cands:
        return det_cands[-1], coeff_cands[-1]

    # Only after local fallback fails, try JSON paths safely.
    if summary:
        rr = summary.get("restart_rows")
        if isinstance(rr, list) and rr:
            for row in reversed(rr):
                det = row.get("selected_dets")
                coeff = row.get("selected_coeff")
                if det and coeff:
                    det_p = Path(det)
                    coeff_p = Path(coeff)
                    if exists_safe(det_p) and exists_safe(coeff_p):
                        return det_p, coeff_p

    raise FileNotFoundError(f"Could not find selected det/coeff files in {d}")

def parse_checkpoint(d: Path) -> dict[str, Any]:
    jp = find_json_summary(d)
    j = read_json(jp)
    e = float(j["E_var"])
    ref = float(j.get("E_CASSCF_or_reference", E_REF))
    gap = float(j.get("gap_vs_CASSCF_mHa", gap_mha(e, ref)))
    dim = int(j.get("final_selected_dim", j.get("selected_dim", -1)))
    n_terms = int(j.get("n_terms", -1))
    obs = j.get("observables", {}) if isinstance(j.get("observables"), dict) else {}
    n_val = float(obs.get("N", 12.0))
    sz_val = float(obs.get("Sz", 0.0))
    meta = j.get("metadata", {}) if isinstance(j.get("metadata"), dict) else {}
    active_tag = str(meta.get("active_rotation_tag", ""))
    det, coeff = find_restart_pair(d, j)
    return {
        "dir": d,
        "json": jp,
        "E_var": e,
        "E_ref": ref,
        "gap_mHa": gap,
        "dim": dim,
        "n_terms": n_terms,
        "N": n_val,
        "Sz": sz_val,
        "active_tag": active_tag,
        "dets": det,
        "coeff": coeff,
    }

def find_default_start(package_root: Path) -> Path:
    patterns = [
        "results/cr2_12_12_v213_restart_15000_to20000_*/step028_restart_r10_to20000",
        "results/**/step028_restart_r10_to20000",
        "results/**/*to20000*",
    ]
    candidates = []
    for pat in patterns:
        for p in package_root.glob(pat):
            if p.is_dir():
                try:
                    ck = parse_checkpoint(p)
                except Exception:
                    continue
                if ck["dim"] >= 19500 and ck["gap_mHa"] < 3.0 and ck["n_terms"] == EXPECTED_TERMS:
                    candidates.append((abs(ck["dim"] - 20000), ck["gap_mHa"], p))
    if not candidates:
        raise FileNotFoundError(
            "Could not auto-find a valid v21.3 20k checkpoint. "
            "Set START_DIR=/path/to/step028_restart_r10_to20000."
        )
    candidates.sort(key=lambda x: x[:2])
    return candidates[0][2]

def validate_checkpoint(ck: dict[str, Any], *, label: str, require_terms: bool = True) -> None:
    if require_terms and ck["n_terms"] != EXPECTED_TERMS:
        raise RuntimeError(f"{label}: wrong terms {ck['n_terms']} != {EXPECTED_TERMS}")
    if ck["active_tag"] and EXPECTED_ACTIVE_TAG not in ck["active_tag"]:
        raise RuntimeError(f"{label}: wrong active rotation tag {ck['active_tag']}")
    if abs(ck["N"] - 12.0) > 1e-5:
        raise RuntimeError(f"{label}: N check failed: {ck['N']}")
    if abs(ck["Sz"]) > 1e-5:
        raise RuntimeError(f"{label}: Sz check failed: {ck['Sz']}")

def build_command(args, ck: dict[str, Any], next_dim: int, outdir: Path, step_label: str, rank: int) -> list[str]:
    return [
        "python3", str(args.engine),
        "--preset", "Cr2_production",
        "--spatial-blocks", "0-1,2-4,5-7,8-9,10-11",
        "--proposal-mode", args.proposal_mode,
        "--pauli-candidate-limit", str(args.pauli_candidate_limit),
        "--max-excitation-rank", str(rank),
        "--max-global-select-rank", str(rank),
        "--selector-mode", args.selector_mode,
        "--en2-score-mode", args.en2_score_mode,
        "--max-important-selected", str(args.max_important_selected),
        "--coeff-cutoff", str(args.coeff_cutoff),
        "--iterations", "1",
        "--add-per-iter", str(args.add_per_step),
        "--max-selected-dim", str(next_dim),
        "--checkpoints", str(next_dim),
        "--diagnostic-top-k", str(args.diagnostic_top_k),
        "--top-report", str(args.top_report),
        "--max-rank-fraction", str(args.max_rank_fraction),
        "--branch-label", f"v213_native_{step_label}",
        "--output-dir", str(outdir),
        "--tag", step_label,
        "--casscf",
        "--restart-dets", str(ck["dets"]),
        "--restart-coeff", str(ck["coeff"]),
        "--restart-energy", f"{ck['E_var']:.16f}",
        "--skip-initial-solve",
    ]

def run_monitored(cmd: list[str], log_path: Path, expected_terms: int, bad_terms: int) -> int:
    print("[CMD] " + " ".join(q(x) for x in cmd), flush=True)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    saw_good_terms = False
    with log_path.open("w", encoding="utf-8") as log:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        assert proc.stdout is not None
        for line in proc.stdout:
            print(line, end="")
            log.write(line)
            log.flush()
            if re.search(rf"\b{bad_terms}\s+terms\b", line):
                proc.kill()
                proc.wait()
                raise RuntimeError(f"Wrong Hamiltonian detected: {bad_terms} terms")
            if re.search(rf"\b{expected_terms}\s+terms\b", line):
                saw_good_terms = True
        rc = proc.wait()
    if rc != 0:
        raise RuntimeError(f"Engine exited with code {rc}")
    if not saw_good_terms:
        raise RuntimeError(f"Did not see expected {expected_terms}-term Hamiltonian in log")
    return rc

def append_progress(path: Path, row: dict[str, Any]) -> None:
    fields = ["step", "dim", "E_var", "gap_mHa", "gain_mHa", "gain_per_kdet", "rank", "outdir", "timestamp"]
    exists = path.exists()
    with path.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        if not exists:
            w.writeheader()
        w.writerow({k: row.get(k, "") for k in fields})

def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--package-root", default=".")
    ap.add_argument("--engine", default="")
    ap.add_argument("--start-dir", default="")
    ap.add_argument("--target-gap-mha", type=float, default=0.5)
    ap.add_argument("--max-dim", type=int, default=30000)
    ap.add_argument("--walltime-seconds", type=int, default=30000)
    ap.add_argument("--add-per-step", type=int, default=500)
    ap.add_argument("--output-base", default="")
    ap.add_argument("--run", action="store_true")
    ap.add_argument("--proposal-mode", default="hybrid")
    ap.add_argument("--selector-mode", default="en2_topk")
    ap.add_argument("--en2-score-mode", default="clipped_abs")
    ap.add_argument("--rank", type=int, default=10)
    ap.add_argument("--unlock-rank", type=int, default=12)
    ap.add_argument("--plateau-gain-per-kdet", type=float, default=0.05)
    ap.add_argument("--pauli-candidate-limit", type=int, default=13750)
    ap.add_argument("--max-important-selected", type=int, default=8000)
    ap.add_argument("--coeff-cutoff", default="1e-06")
    ap.add_argument("--diagnostic-top-k", type=int, default=120)
    ap.add_argument("--top-report", type=int, default=40)
    ap.add_argument("--max-rank-fraction", type=float, default=0.75)
    args = ap.parse_args(argv)

    root = Path(args.package_root).expanduser().resolve()
    args.engine = Path(args.engine).expanduser().resolve() if args.engine else root / "engines/cas12/cr2_v1433_cas12_adaptive.py"
    if not args.engine.exists():
        raise SystemExit(f"Missing v21.3 engine: {args.engine}")

    start_dir = Path(args.start_dir).expanduser().resolve() if args.start_dir else find_default_start(root)
    ck = parse_checkpoint(start_dir)
    validate_checkpoint(ck, label="start")
    if ck["dim"] < 19500 or ck["gap_mHa"] > 3.0:
        raise SystemExit(f"Refusing start checkpoint dim={ck['dim']} gap={ck['gap_mHa']}")

    if not args.output_base:
        args.output_base = str(root / "results" / f"cr2_12_12_v213_native_restart_20k_to_0p5_{time.strftime('%Y%m%d_%H%M%S')}")
    out_base = Path(args.output_base).expanduser().resolve()
    out_base.mkdir(parents=True, exist_ok=True)

    master_log = out_base / "restart_master.log"
    progress_csv = out_base / "restart_progress.csv"

    def log(msg: str):
        print(msg, flush=True)
        with master_log.open("a", encoding="utf-8") as f:
            f.write(msg + "\n")

    log("[START] native v21.3 restart v2")
    log(f"PACKAGE_ROOT={root}")
    log(f"ENGINE={args.engine}")
    log(f"OUT_BASE={out_base}")
    log(f"START_DIR={start_dir}")
    log(f"START_DIM={ck['dim']} START_E={ck['E_var']:.16f} START_GAP_MHA={ck['gap_mHa']:.12f} TERMS={ck['n_terms']} N={ck['N']} Sz={ck['Sz']} ACTIVE_TAG={ck['active_tag']}")
    log(f"DETS={ck['dets']}")
    log(f"COEFF={ck['coeff']}")
    log(f"TARGET_GAP_MHA={args.target_gap_mha} MAX_DIM={args.max_dim} WALLTIME_SECONDS={args.walltime_seconds}")

    step = 0
    recent_gains = []
    t0 = time.time()

    while ck["gap_mHa"] > args.target_gap_mha and ck["dim"] < args.max_dim:
        elapsed = time.time() - t0
        if elapsed > args.walltime_seconds:
            log(f"[STOP] walltime reached elapsed={elapsed:.1f}s")
            break

        rank = args.rank
        if len(recent_gains) >= 2 and all(x < args.plateau_gain_per_kdet for x in recent_gains[-2:]):
            rank = args.unlock_rank
            log(f"[UNLOCK] recent gains {recent_gains[-2:]} below threshold; trying rank {rank}")

        next_dim = min(ck["dim"] + args.add_per_step, args.max_dim)
        step_label = f"step{step:03d}_native_r{rank}_to{next_dim}"
        outdir = out_base / step_label
        outdir.mkdir(parents=True, exist_ok=True)
        log(f"\n[RUN] {step_label} from dim={ck['dim']} gap={ck['gap_mHa']:.12f} E={ck['E_var']:.16f}")

        cmd = build_command(args, ck, next_dim, outdir, step_label, rank)
        if not args.run:
            log("[DRY-RUN] " + " ".join(q(x) for x in cmd))
            log("[DRY-RUN] Add RUN=1 in the shell wrapper or --run to execute.")
            return 0

        run_monitored(cmd, outdir / "run.log", EXPECTED_TERMS, BAD_TERMS)

        new_ck = parse_checkpoint(outdir)
        validate_checkpoint(new_ck, label=step_label)
        if new_ck["E_var"] > ck["E_var"] + 1e-10:
            raise RuntimeError(f"Non-monotone E_var: previous={ck['E_var']:.16f} new={new_ck['E_var']:.16f}")
        if new_ck["gap_mHa"] > ck["gap_mHa"] + 1e-6:
            raise RuntimeError(f"Gap worsened: previous={ck['gap_mHa']:.12f} new={new_ck['gap_mHa']:.12f}")

        gain = ck["gap_mHa"] - new_ck["gap_mHa"]
        denom = max((new_ck["dim"] - ck["dim"]) / 1000.0, 1e-9)
        gain_per_k = gain / denom
        recent_gains.append(gain_per_k)
        log(f"[OK] dim={new_ck['dim']} E={new_ck['E_var']:.16f} gap={new_ck['gap_mHa']:.12f} gain={gain:.12f} gain_per_kdet={gain_per_k:.12f}")

        append_progress(progress_csv, {
            "step": step,
            "dim": new_ck["dim"],
            "E_var": f"{new_ck['E_var']:.16f}",
            "gap_mHa": f"{new_ck['gap_mHa']:.12f}",
            "gain_mHa": f"{gain:.12f}",
            "gain_per_kdet": f"{gain_per_k:.12f}",
            "rank": rank,
            "outdir": str(outdir),
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        })

        ck = new_ck
        step += 1

    log(f"\n[DONE] final_dim={ck['dim']} final_E={ck['E_var']:.16f} final_gap_mHa={ck['gap_mHa']:.12f}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
