#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PACKAGE_ROOT="${PACKAGE_ROOT:-$SCRIPT_DIR}"
cd "$PACKAGE_ROOT"

DRIVER="${DRIVER:-$PACKAGE_ROOT/v213_native_restart_safe_v2.py}"
ENGINE="${ENGINE:-$PACKAGE_ROOT/engines/cas12/cr2_v1433_cas12_adaptive.py}"

TARGET_GAP_MHA="${TARGET_GAP_MHA:-0.5}"
MAX_DIM="${MAX_DIM:-30000}"
WALLTIME_SECONDS="${WALLTIME_SECONDS:-30000}"
ADD_PER_STEP="${ADD_PER_STEP:-500}"
START_DIR="${START_DIR:-}"

PAULI_CANDIDATE_LIMIT="${PAULI_CANDIDATE_LIMIT:-13750}"
MAX_IMPORTANT_SELECTED="${MAX_IMPORTANT_SELECTED:-8000}"
MAX_RANK_FRACTION="${MAX_RANK_FRACTION:-0.75}"
RANK="${RANK:-10}"
UNLOCK_RANK="${UNLOCK_RANK:-12}"

echo "PACKAGE_ROOT=$PACKAGE_ROOT"
echo "DRIVER=$DRIVER"
echo "ENGINE=$ENGINE"
echo "START_DIR=$START_DIR"
echo "TARGET_GAP_MHA=$TARGET_GAP_MHA"
echo "MAX_DIM=$MAX_DIM"
echo "WALLTIME_SECONDS=$WALLTIME_SECONDS"

[ -f "$DRIVER" ] || { echo "Missing driver: $DRIVER"; exit 1; }
[ -f "$ENGINE" ] || { echo "Missing engine: $ENGINE"; exit 1; }

RUN_FLAG=()
if [ "${RUN:-0}" = "1" ]; then
  RUN_FLAG=(--run)
else
  echo "Dry-run only. To execute: RUN=1 $0"
fi

START_ARGS=()
if [ -n "$START_DIR" ]; then
  START_ARGS=(--start-dir "$START_DIR")
fi

python3 "$DRIVER" \
  --package-root "$PACKAGE_ROOT" \
  --engine "$ENGINE" \
  "${START_ARGS[@]}" \
  --target-gap-mha "$TARGET_GAP_MHA" \
  --max-dim "$MAX_DIM" \
  --walltime-seconds "$WALLTIME_SECONDS" \
  --add-per-step "$ADD_PER_STEP" \
  --rank "$RANK" \
  --unlock-rank "$UNLOCK_RANK" \
  --pauli-candidate-limit "$PAULI_CANDIDATE_LIMIT" \
  --max-important-selected "$MAX_IMPORTANT_SELECTED" \
  --max-rank-fraction "$MAX_RANK_FRACTION" \
  "${RUN_FLAG[@]}"
